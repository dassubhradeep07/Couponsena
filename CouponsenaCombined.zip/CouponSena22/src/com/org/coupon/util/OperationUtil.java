package com.org.coupon.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;

import com.org.coupon.dto.CsUserDetailsMaster;
import com.org.coupon.dto.CsUserMissingSales;
import com.org.coupon.pojo.RequestMissingOrderPOJO;
import com.org.coupon.pojo.RequestUserRegistrationPOJO;
import com.org.coupon.pojo.UserDeatilsPOJO;

public class OperationUtil {

	private static OperationUtil operationUtil = null;

	public static OperationUtil getInstance() {
		if (operationUtil == null) {
			operationUtil = new OperationUtil();
		}
		return operationUtil;
	}

	public String getFinalJsonString(String couponDeals, String brands) {
		String finalString = "";
		try {
			couponDeals = couponDeals.replace("\\", "");
			brands = brands.replace("\\", "");
			System.out.println("couponDeals" + "-----" + "brands" + couponDeals + "--" + brands);
			finalString = "{" + '"' + "value" + '"' + ":[{" + '"' + "coupon" + '"' + ":" + couponDeals + "},{" + '"'
					+ "brand" + '"' + ":" + brands + "}]}";
			System.out.println("#getFinalJsonString() finalString--" + finalString);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return finalString;
	}
	
	public String getFinalJsonStringForMenu(String jsonCategory,String jsonBrand) {
		String finalString = "";
		try {
			jsonCategory = jsonCategory.replace("\\", "");
			jsonBrand = jsonBrand.replace("\\", "");
			System.out.println("jsonCategory" + "-----" + "jsonBrand" + jsonCategory + "--" + jsonBrand);
			finalString = "{" + '"' + "value" + '"' + ":[{" + '"' + "category" + '"' + ":" + jsonCategory + "},{" + '"'
					+ "brand" + '"' + ":" + jsonBrand + "}]}";
			System.out.println("#getFinalJsonStringForMenu() finalString--" + finalString);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return finalString;
	}

	public String getFinalJsonStringForFilter(String dealTypeJson,String categoryType) {
		String finalString = "";
		try {
			dealTypeJson = dealTypeJson.replace("\\", "");
			categoryType = categoryType.replace("\\", "");
			System.out.println("dealTypeJson" + "-----" + "categoryType" + dealTypeJson + "--" + categoryType);
			finalString = "{" + '"' + "value" + '"' + ":[{" + '"' + "dealType" + '"' + ":" + dealTypeJson + "},{" + '"'+ "category" + '"' + ":" + categoryType + "}]}";
			System.out.println("#getFinalJsonStringForFilter() finalString--" + finalString);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return finalString;
	}

	public CsUserMissingSales mapPojoToTable(RequestMissingOrderPOJO requestMissingOrderPojo,String userId) {
		// TODO Auto-generated method stub
		CsUserMissingSales userMissingSales = new CsUserMissingSales();
		try {
			userMissingSales.setAddAttachment(requestMissingOrderPojo.getAttachment());
			userMissingSales.setCouponCodeUsed(requestMissingOrderPojo.getUsedCouponcode());
			userMissingSales.setDateOfTransaction(requestMissingOrderPojo.getDateOfTransaction());
			userMissingSales.setMerchantName(requestMissingOrderPojo.getMerchantName());
			userMissingSales.setUserId(Integer.parseInt(userId));
			userMissingSales.setTotalAmountPaid(requestMissingOrderPojo.getTotalAmountPaid());
			userMissingSales.setTransactionId(requestMissingOrderPojo.getTransactionId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userMissingSales;
	}

	public CsUserDetailsMaster mapRequestToPojoForRegistration(RequestUserRegistrationPOJO requestUserRegistrationPojo) {

		System.out.println("requestUserRegistrationPojo.getDob()" + requestUserRegistrationPojo.getDob());
		String dateStr = requestUserRegistrationPojo.getDob();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		CsUserDetailsMaster userDetails = null;
		Date date = null;
		try {
			date = sdf.parse(dateStr);
			System.out.println("date" + date);
			System.out.println("newdob" + new SimpleDateFormat("MM/dd/yyyy").format(date));
			userDetails = new CsUserDetailsMaster();
			userDetails.setBankAccountNumber(requestUserRegistrationPojo.getBankAccountNumber());
			userDetails.setBankBranchName(requestUserRegistrationPojo.getBankBranchName());
			userDetails.setBankName(requestUserRegistrationPojo.getBankName());
			userDetails.setCity(requestUserRegistrationPojo.getCity());
			userDetails.setDob(new SimpleDateFormat("MM/dd/yyyy").format(date));
			userDetails.setEmail(requestUserRegistrationPojo.getEmail());
			userDetails.setFirstName(requestUserRegistrationPojo.getFirstName());
			userDetails.setGender(requestUserRegistrationPojo.getGender());
			userDetails.setIfsccode(requestUserRegistrationPojo.getIfsccode());
			userDetails.setLastName(requestUserRegistrationPojo.getLastName());
			userDetails.setMobileNumber(requestUserRegistrationPojo.getMobileNumber());
			userDetails.setPassword(requestUserRegistrationPojo.getPassword());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return userDetails;
	}
	
	public CsUserDetailsMaster mapRequestToPojoForUpdate(RequestUserRegistrationPOJO requestUserRegistrationPojo,CsUserDetailsMaster userDetails) {

		System.out.println("requestUserRegistrationPojo.getDob()" + requestUserRegistrationPojo.getDob());
		String dateStr = requestUserRegistrationPojo.getDob();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date date = null;
		try {
			if(dateStr!=null)
			{
				date = sdf.parse(dateStr);
				System.out.println("date" + date);
				System.out.println("newdob" + new SimpleDateFormat("MM/dd/yyyy").format(date));
			}
			if(requestUserRegistrationPojo.getBankAccountNumber()!=null)
			userDetails.setBankAccountNumber(requestUserRegistrationPojo.getBankAccountNumber());
			if(requestUserRegistrationPojo.getBankBranchName()!=null)
			userDetails.setBankBranchName(requestUserRegistrationPojo.getBankBranchName());
			if(requestUserRegistrationPojo.getBankName()!=null)
			userDetails.setBankName(requestUserRegistrationPojo.getBankName());
			if(requestUserRegistrationPojo.getCity()!=null)
			userDetails.setCity(requestUserRegistrationPojo.getCity());
			if(date!=null)
			{
				userDetails.setDob(date.toString());
			}
			if(requestUserRegistrationPojo.getEmail()!=null)
			userDetails.setEmail(requestUserRegistrationPojo.getEmail());
			if(requestUserRegistrationPojo.getFirstName()!=null)
			userDetails.setFirstName(requestUserRegistrationPojo.getFirstName());
			if(requestUserRegistrationPojo.getGender()!=null)
			userDetails.setGender(requestUserRegistrationPojo.getGender());
			if(requestUserRegistrationPojo.getIfsccode()!=null)
			userDetails.setIfsccode(requestUserRegistrationPojo.getIfsccode());
			if(requestUserRegistrationPojo.getLastName()!=null)
			userDetails.setLastName(requestUserRegistrationPojo.getLastName());
			if(requestUserRegistrationPojo.getMobileNumber()!=null)
			userDetails.setMobileNumber(requestUserRegistrationPojo.getMobileNumber());
			if(requestUserRegistrationPojo.getPassword()!=null)
			userDetails.setPassword(requestUserRegistrationPojo.getPassword());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return userDetails;
	}
	
	public UserDeatilsPOJO mapRequestToPojoForDetails(CsUserDetailsMaster csUserDetailsMaster) {

		System.out.println("csUserDetailsMaster" + csUserDetailsMaster);
		UserDeatilsPOJO userDetails = null;
		String dateStr = csUserDetailsMaster.getDob();
		try {
			System.out.println("dateStr-" + dateStr);
			userDetails = new UserDeatilsPOJO();
			userDetails.setBankAccountNumber(csUserDetailsMaster.getBankAccountNumber());
			userDetails.setBankBranchName(csUserDetailsMaster.getBankBranchName());
			userDetails.setBankName(csUserDetailsMaster.getBankName());
			userDetails.setCity(csUserDetailsMaster.getCity());
			userDetails.setDob(dateStr);
			userDetails.setEmail(csUserDetailsMaster.getEmail());
			userDetails.setFirstName(csUserDetailsMaster.getFirstName());
			userDetails.setGender(csUserDetailsMaster.getGender());
			userDetails.setIfsccode(csUserDetailsMaster.getIfsccode());
			userDetails.setLastName(csUserDetailsMaster.getLastName());
			userDetails.setMobileNumber(csUserDetailsMaster.getMobileNumber());
			userDetails.setPassword(csUserDetailsMaster.getPassword());
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return userDetails;
	}

	public static String encryptPassword(String password) {
		byte[] byteArray = null;
		String encodedString = "";
		if (password != null && !password.trim().equalsIgnoreCase("")) {
			byteArray = Base64.encodeBase64(password.getBytes());
		}
		encodedString = Arrays.toString(byteArray);
		return encodedString;
	}

	public static String decryptPassword(String password) {
		byte[] byteArray = null;
		String decodedString = "";
		if (password != null && !password.trim().equalsIgnoreCase("")) {
			byteArray = Base64.decodeBase64(password.getBytes());
		}
		decodedString = Arrays.toString(byteArray);
		return decodedString;
	}

	public static String encryptSessionId(String sessionId) {

		return "";
	}

	public static String decryptSessionId(String sessionId) {

		return "";
	}
	
}
