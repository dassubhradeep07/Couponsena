package com.org.coupon.util;

import com.org.coupon.pojo.ResponseStatusPOJO;

public class ServiceUtil {
	ResponseStatusPOJO responseStatusPojo;
	private static ServiceUtil serviceUtil;
	
	public static ServiceUtil getInstance()
	{
		if(serviceUtil == null)
		{
			serviceUtil = new ServiceUtil();
		}
		return serviceUtil;
	}
	
	public ResponseStatusPOJO getResponse(String code,String description,String status)
	{
		responseStatusPojo = new ResponseStatusPOJO();
		responseStatusPojo.setCode(code);
		responseStatusPojo.setDescription(description);
		responseStatusPojo.setStatus(status);
		return responseStatusPojo;
	}
	
}
