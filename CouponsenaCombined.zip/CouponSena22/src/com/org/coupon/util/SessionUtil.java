package com.org.coupon.util;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.org.coupon.dto.CsUserDetailsMaster;

public class SessionUtil implements HttpSessionListener{
	public static HttpSession session;
	public static Cookie userEmailCookie;
	private static ConcurrentHashMap<String, HttpSession> activeUsers = new ConcurrentHashMap<String, HttpSession>();
	
	public static HttpSession getSession() {
		return session;
	}

	public static void setSession(HttpSession session) {
		SessionUtil.session = session;
	}

	public static Cookie getUserEmailCookie() {
		return userEmailCookie;
	}

	public static void setUserEmailCookie(Cookie userEmailCookie) {
		SessionUtil.userEmailCookie = userEmailCookie;
	}

	public static ConcurrentHashMap<String, HttpSession> getActiveUsers() {
		return activeUsers;
	}

	public static void setActiveUsers(ConcurrentHashMap<String, HttpSession> activeUsers) {
		SessionUtil.activeUsers = activeUsers;
	}

	public static String setSessionAttributes(HttpServletRequest httpRequest,HttpServletResponse httpResponse,CsUserDetailsMaster csUserDetailsMaster)
	{
		HttpSession httpsession;
		System.out.println("User Object Not Null");
		httpsession = httpRequest.getSession(true);
		String  sessionId = httpsession.getId();
		sessionId = sessionId+"_"+System.currentTimeMillis();
		System.out.println("sessionId is not null --> "+sessionId);
		System.out.println("Created new sessionObj"+httpsession);
		activeUsers.put(sessionId, httpsession);
		httpsession.setMaxInactiveInterval(1*60);
		if(httpResponse!=null)
		{
			System.out.println("httpResponse is Not null");
		}else
		{
			System.out.println("httpResponse is null");
		}
		httpsession.setAttribute("userFirstName", csUserDetailsMaster.getFirstName());
		httpsession.setAttribute("userEmail", csUserDetailsMaster.getEmail());
		httpsession.setAttribute("userId", csUserDetailsMaster.getUserId());
		System.out.println("Itz Not-------------->Enter Into Operation----->");
		String value1= httpsession.getAttribute("userFirstName").toString();
		System.out.println("Value From Session--->"+value1);
		httpsession.setAttribute("name", csUserDetailsMaster.getFirstName());
		System.out.println("activeUsers Map - "+activeUsers);
		return sessionId;
	}
	
	public void sessionCreated(HttpServletRequest httpRequest){
        HttpSession    session     = httpRequest.getSession();        
        SessionUtil.getActiveUsers().put(session.getId(), session);
    }
	
	public static boolean validateAndDeactiveSessionId(String sessionId)
	{
		boolean flag = false;
		HttpSession httpSession = null;
		try
		{
			System.out.println("activeUsers---"+activeUsers);
			if(activeUsers!=null)
			{
				System.out.println("activeUsers.keySet()--->"+activeUsers.keySet());
				if(activeUsers.containsKey(sessionId))
				{
					System.out.println("Delete Key present--->");
				}
				System.out.println("activeUsers.get(sessionId)---"+activeUsers.get(sessionId));
				if(activeUsers.get(sessionId) != null)
				{
					httpSession = activeUsers.get(sessionId);
					httpSession.invalidate();
					System.out.println("httpSession.invalidate() done");
					activeUsers.remove(sessionId);
					flag = true;
					System.out.println("Deactivated Done---------------------->");
				}
			}
		}catch(Exception e)
		{
			flag = true;
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public void sessionCreated(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXThis sessionCreated Event is Getting Called.XXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXThis sessionDestroyed Event is Getting Called.XXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		System.out.println("Active UserMap Now--"+activeUsers);
		String idKey = "";
		try
		{
			if(arg0.getSession()!=null)
			{
				System.out.println("arg0.getSession().getId()---"+arg0.getSession().getId());
				if(activeUsers!=null)
				{
					Iterator iterator = ((Set<String>) activeUsers.keySet()).iterator(); 
					while(iterator.hasNext())
					{
						idKey = (String) iterator.next();
						System.out.println("idKey--"+idKey);
						if(idKey.contains(arg0.getSession().getId()))
							{
								activeUsers.remove(idKey);
								System.out.println("Remove Done----");
							}
					}
				}
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("Active UserMap Now After remove--"+activeUsers);
	}
}
