package com.org.coupon.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.org.coupon.dao.CouponDaoImpl;
import com.org.coupon.dto.CsMetatagsMaster;
import com.org.coupon.dto.CsUserDetailsMaster;
import com.org.coupon.pojo.DealOfTheDayPOJO;
import com.org.coupon.pojo.FilterCategoryPOJO;
import com.org.coupon.pojo.FilterDealTypePOJO;
import com.org.coupon.pojo.MetaTagsPOJO;
import com.org.coupon.pojo.PopularBrandPOJO;
import com.org.coupon.pojo.RequestLoginPOJO;
import com.org.coupon.pojo.RequestLogoutPojo;
import com.org.coupon.pojo.RequestMissingOrderPOJO;
import com.org.coupon.pojo.RequestUserRegistrationPOJO;
import com.org.coupon.pojo.ResponseStatusPOJO;
import com.org.coupon.pojo.TopCategoryPOJO;
import com.org.coupon.pojo.TopCouponDealsPOJO;
import com.org.coupon.pojo.UserDeatilsPOJO;
import com.org.coupon.service.CouponServiceImpl;
import com.org.coupon.util.OperationUtil;
import com.org.coupon.util.ServiceUtil;
import com.org.coupon.util.SessionUtil;

@Path("/GetCouponDetails")
public class CouponController {
	
	
	//Get Popular Brands & Featured Coupons in HomePage 
	@GET
	@Path("/getHomeDetails")
	@Produces(MediaType.APPLICATION_JSON)
	public String getHomePageDetails(@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse) throws Exception {
		List<TopCouponDealsPOJO> topCouponDealsData = CouponServiceImpl.getInstance().getLatestTopDeals();
		List<PopularBrandPOJO> popularBrandData = CouponServiceImpl.getInstance().getTopCampains();
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String jsonCoupon = gson.toJson(topCouponDealsData);
        String jsonBrand = gson.toJson(popularBrandData);
		System.out.println("### jsonCoupon -- "+jsonCoupon);
		System.out.println("### jsonBrand -- "+jsonBrand);
		String finalString=OperationUtil.getInstance().getFinalJsonString(jsonCoupon, jsonBrand);
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		System.out.println("#getHomePageDetails finalString---"+finalString);
		return finalString;
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/getHomeDetails
	}
	
	//Get Navigation Menu Like - Category,Brand,Store
	@GET
	@Path("/getSearchFilter")
	@Produces(MediaType.APPLICATION_JSON)
	public String getSearchFilter(@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse) throws Exception {
		List<TopCategoryPOJO> topCategoryPOJOData = CouponServiceImpl.getInstance().getTopCategory();
		List<PopularBrandPOJO> popularBrandData = CouponServiceImpl.getInstance().getTopCampains();
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String jsonCategory = gson.toJson(topCategoryPOJOData);
        String jsonBrand = gson.toJson(popularBrandData);
		System.out.println("### jsonCategory -- "+jsonCategory);
		System.out.println("### jsonBrand -- "+jsonBrand);
		String finalString=OperationUtil.getInstance().getFinalJsonStringForMenu(jsonCategory, jsonBrand);
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		System.out.println("#getSearchFilter finalString---"+finalString);
		return finalString;
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/getSearchFilter
	}
	
	//Get Deal Of The day for Campaigns
	@GET
	@Path("/getDealOfTheDay")
	@Produces(MediaType.APPLICATION_JSON)
	public String getDealOfTheDay(@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse) throws Exception {
		List<DealOfTheDayPOJO> dealOfTheDayPOJOData = CouponServiceImpl.getInstance().getDealOfTheDay();
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String csDotdFlipkartValue = gson.toJson(dealOfTheDayPOJOData);
		System.out.println("### getDealOfTheDay finalString -- "+csDotdFlipkartValue);
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		return csDotdFlipkartValue;
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/getDealOfTheDay
	}
	
	//Get Coupons for Product Details page as per category
	@GET
	@Path("/getCategory/{category}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getCouponsByCategories(@PathParam("category") String categoryName,@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse) throws Exception {
		List<TopCouponDealsPOJO> topCouponDealsData = CouponServiceImpl.getInstance().getDealsByCategory(categoryName);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String jsonCoupon = gson.toJson(topCouponDealsData);
        httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		System.out.println("### jsonCoupon -- "+jsonCoupon);
		return jsonCoupon;
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/getCategory/{category}
	}
	
	//Get Coupons for Product Details page as per stores
	@GET
	@Path("/getStore/{store}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getCouponsByStores(@PathParam("store") String storeName,@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse) throws Exception {
		List<TopCouponDealsPOJO> topCouponDealsData = CouponServiceImpl.getInstance().getDealsByStore(storeName);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String jsonCoupon = gson.toJson(topCouponDealsData);
        httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		System.out.println("### getCouponsByStores -- jsonCoupon -- "+jsonCoupon);
		return jsonCoupon;
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/getStore/{store}
	}
	
	//Get Coupons for Product Details page as per brand
	@GET
	@Path("/getBrand/{brand}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getCouponsByBrands(@PathParam("brand") String brandName,@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse) throws Exception {
		List<TopCouponDealsPOJO> topCouponDealsData = CouponServiceImpl.getInstance().getDealsByBrand(brandName);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String jsonCoupon = gson.toJson(topCouponDealsData);
        httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		System.out.println("### getCouponsByBrands -- jsonCoupon -- "+jsonCoupon);
		return jsonCoupon;
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/getBrand/{brand}
	}
	
	//Get Search Filter for particular brand in product details page
	@GET
	@Path("/getFilter/{brand}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getCouponsFilter(@PathParam("brand") String brandName,@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse) throws Exception {
		List<FilterDealTypePOJO> filterDealTypePOJOList = CouponDaoImpl.getInstance().getFilterDealOptions(brandName);
		List<FilterCategoryPOJO> filterCategoryPOJOList = CouponDaoImpl.getInstance().getFilterCategoryOptions(brandName);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		String dealTypeJson = gson.toJson(filterDealTypePOJOList);
        String categoryType = gson.toJson(filterCategoryPOJOList);
        System.out.println("### dealTypeJson -- jsonFilter -- "+dealTypeJson);
        System.out.println("### categoryType -- jsonFilter -- "+categoryType);
		String finalString=OperationUtil.getInstance().getFinalJsonStringForFilter(dealTypeJson, categoryType);
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		System.out.println("### getCouponsFilter -- jsonFilter -- "+finalString);
		return finalString;
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/getFilter/{brand}
	}
	
	//Get All Store & Show in all store Page
	@GET
	@Path("/getAllStore")
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllStore(@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse) throws Exception {
		List<PopularBrandPOJO> allBrandData = CouponServiceImpl.getInstance().getAllCampains();
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		String allBrandDataValue = gson.toJson(allBrandData);
        System.out.println("### dealTypeJson -- jsonFilter -- "+allBrandDataValue);
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		System.out.println("### getAllStore -- allBrandDataValue -- "+allBrandDataValue);
		return allBrandDataValue;
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/getAllStore
	}
	
	
	//Get All Catogeory & Show in all store Page
	@GET
	@Path("/getAllCategory")
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllCategory(@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse) throws Exception {
		List<TopCategoryPOJO> allcategoryData = CouponServiceImpl.getInstance().getAllCategory();
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		String allCategryDataValue = gson.toJson(allcategoryData);
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		System.out.println("### getAllCategory -- allCategryDataValue -- "+allCategryDataValue);
		return allCategryDataValue;
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/getAllCategory
	}
	
	//Get Meta tags For Every Page
	@POST
	@Path("/getMetaTags")
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllMetaTags(@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse,MetaTagsPOJO metaTagsPOJO) throws Exception {
		String name = "";
		String type = "";
		name = metaTagsPOJO.getName();
		type = metaTagsPOJO.getType();
		CsMetatagsMaster csMetatagsMaster = null;
		if(name!=null && !name.equalsIgnoreCase("") && type!=null && !type.equalsIgnoreCase(""))
		{
			csMetatagsMaster = CouponServiceImpl.getInstance().getMetaTagInfo(name,type);
		}
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		String csMetatagsMasterValue = gson.toJson(csMetatagsMaster);
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		System.out.println("### getAllMetaTags -- csMetatagsMasterValue -- "+csMetatagsMasterValue);
		return csMetatagsMasterValue;
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/getMetaTags
	}
	
	
	
	/****************************************************User Related services*****************************************************/	
	
	
	 
	/*@POST
	@Path("/getEarnings")
	@Produces(MediaType.APPLICATION_JSON)
	public String getUserEarnings(@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse,RequestLogoutPojo requestLogoutPojo) throws Exception {
		String message="";
		UserSales userSales = null;
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		if(requestLogoutPojo!=null)
		{
			System.out.println("sessionPojo.getSessionId()--"+requestLogoutPojo.getEncryptedId());
			System.out.println("activeUsers is --> "+SessionUtil.getActiveUsers());
			userSales =  CouponServiceImpl.getInstance().getUserEarnings(SessionUtil.getSession().getAttribute("userId").toString());
			if(userSales==null)
			{
				message = "User Sales Not Found";
				System.out.println("errorMessage getUserEarnings() --"+message);
				return message;
			}else
			{
				System.out.println("Not NULL userSales ----");
				message = "User Have AnySale";
				System.out.println("Success getUserEarnings() --"+message);
				return message;
			}
		}else
		{
			System.out.println("Session Null in getUserEarnings-->>");
			message = "User Not Logged In";
			System.out.println("errorMessage getUserEarnings() --"+message);
			return message;
		}
		//http://localhost:8080CouponSena/rest/GetCouponDetails/getEarnings
	}*/
	
	@POST
	@Path("/informMissingCashback")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response informMissingCashback(RequestMissingOrderPOJO requestMissingOrderPojo, @Context HttpServletResponse httpResponse) throws Exception {
		System.out.println("###informMissingCashback().......Start");
		ResponseStatusPOJO responseStatusPojo = null;
		String userId = "";
		boolean flag=false;
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		if(requestMissingOrderPojo!=null)
		{
			System.out.println("sessionPojo.getSessionId()--"+requestMissingOrderPojo.getEncryptedId());
			System.out.println("activeUsers is --> "+SessionUtil.getActiveUsers());
			HttpSession elementSession = SessionUtil.getActiveUsers().get(requestMissingOrderPojo.getEncryptedId());
			if(elementSession!=null)
			{
				System.out.println("elementSession Not NULL-"+elementSession);
				System.out.println("Here It is from map"+elementSession.getId());
				
				if(elementSession.getAttribute("userId")!=null)
				{
					userId = elementSession.getAttribute("userId").toString();
					if(userId!=null)
					{
						System.out.println("userId NOT NULL--"+userId);
						System.out.println("### requestUserUpdatePojo--"+requestMissingOrderPojo.toString());
						flag = CouponServiceImpl.getInstance().informMissingCoupon(requestMissingOrderPojo,userId);
					}
				}
				
				if(flag)
				{
					responseStatusPojo = ServiceUtil.getInstance().getResponse("200", "Query Submitted", "OK");
				}else
				{
					responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "Query Submit Falied", "Falied");
				}
			}else
			{
				responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "Query Submit Falied", "Falied");
			}
			
		}else
		{
			responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "Query Submit Falied", "Falied");
		}
		System.out.println("###informMissingCashback().......End");
		return Response.status(200).entity(responseStatusPojo).build();
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/informMissingCashback
	}
	
	@POST
	@Path("/userRegistration")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response userRegistration(RequestUserRegistrationPOJO requestUserRegistrationPojo, @Context HttpServletResponse httpResponse) throws Exception {
		ResponseStatusPOJO responseStatusPojo;
		boolean flag=false;
		if(requestUserRegistrationPojo!=null)
		{
			System.out.println("### requestUserRegistrationPojo--"+requestUserRegistrationPojo.toString());
			flag = CouponServiceImpl.getInstance().userRegistration(requestUserRegistrationPojo);
			if(flag)
			{
				responseStatusPojo = ServiceUtil.getInstance().getResponse("200", "User Successfully Registered", "OK");
			}else
			{
				responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "User Registration Falied", "Falied");
			}
		}else
		{
			responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "User Registration Falied", "Falied");
		}
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		return Response.status(200).entity(responseStatusPojo).build();
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/userRegistration
	}
	
	
	@POST
	@Path("/userLogin")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response userLogin(RequestLoginPOJO requestLoginPOJO,@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse) throws Exception {
		ResponseStatusPOJO responseStatusPojo = new ResponseStatusPOJO();
		CsUserDetailsMaster csUserDetailsMaster = null;
		String sessionId= "";
		if(requestLoginPOJO!=null)
		{
			System.out.println("###requestUserRegistrationPojo--"+requestLoginPOJO.toString());
			csUserDetailsMaster = CouponServiceImpl.getInstance().userLogin(requestLoginPOJO);
			if(csUserDetailsMaster!=null)
			{
				sessionId = SessionUtil.setSessionAttributes(httpRequest,httpResponse,csUserDetailsMaster);
				
				if(sessionId!=null && sessionId.length()!=0)
				{
					responseStatusPojo = ServiceUtil.getInstance().getResponse("200", sessionId, "OK");
				}else
				{
					System.out.println("Flag False");
					responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "User Login Falied", "Falied");
				}
			}else
			{
				responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "User Login Falied", "Falied");
			}
		}else
		{
			responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "User Login Falied", "Falied");
		}
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		return Response.status(200).entity(responseStatusPojo).build();
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/userLogin
	}
	
	@POST
	@Path("/userDetailsUpdate")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response userDetailsUpdate(RequestUserRegistrationPOJO requestUserRegistrationPojo, @Context HttpServletResponse httpResponse) throws Exception {
		ResponseStatusPOJO responseStatusPojo = null;
		boolean flag=false;
		CsUserDetailsMaster csUserDetailsMaster = null;
		if(requestUserRegistrationPojo!=null)
		{
			System.out.println("sessionPojo.getSessionId()--"+requestUserRegistrationPojo.getEncryptedId());
			System.out.println("activeUsers is --> "+SessionUtil.getActiveUsers());
			HttpSession elementSession = SessionUtil.getActiveUsers().get(requestUserRegistrationPojo.getEncryptedId());
			if(elementSession!=null)
			{
				System.out.println("elementSession Not NULL-"+elementSession);
				System.out.println("Here It is from map"+elementSession.getId());
			}else
			{
				System.out.println("elementSession is null");
			}
			if(elementSession.getAttribute("userId")!=null)
			{
				csUserDetailsMaster =  CouponServiceImpl.getInstance().getUserDetails(elementSession.getAttribute("userId").toString());
				if(csUserDetailsMaster!=null)
				{
					System.out.println("csUserDetailsMaster.getUserId() NOT NULL--"+csUserDetailsMaster.getUserId());
					System.out.println("### requestUserUpdatePojo--"+requestUserRegistrationPojo.toString());
					int userId = csUserDetailsMaster.getUserId();
					flag = CouponServiceImpl.getInstance().userUpdate(requestUserRegistrationPojo,userId);
				}
				if(flag)
				{
					responseStatusPojo = ServiceUtil.getInstance().getResponse("200", "User Successfully Updated", "OK");
				}else
				{
					responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "User Details Update Falied", "Falied");
				}
			}else
			{
				responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "User Details Update Falied", "Falied");
			}
		}else
		{
			responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "User Details Update Falied", "Falied");
		}
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		return Response.status(200).entity(responseStatusPojo).build();
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/userDetailsUpdate
	}
	
	@POST
	@Path("/getUserDetails")
	@Produces(MediaType.APPLICATION_JSON)
	public String getUserDetails(@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse,RequestLogoutPojo requestLogoutPojo) throws Exception {
		ResponseStatusPOJO responseStatusPojo = new ResponseStatusPOJO();
		CsUserDetailsMaster csUserDetailsMaster = null;
		UserDeatilsPOJO userDeatilsPOJO = null;
		String errorMessage="";
		String userDetails = "";
		//if(session!=null)
		httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Vary", "Accept-Encoding");
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		if(requestLogoutPojo!=null)
		{
			System.out.println("sessionPojo.getSessionId()--"+requestLogoutPojo.getEncryptedId());
			System.out.println("activeUsers is --> "+SessionUtil.getActiveUsers());
			System.out.println("SessionUtil.getActiveUsers().get(requestLogoutPojo.getEncryptedId())--"+SessionUtil.getActiveUsers().get(requestLogoutPojo.getEncryptedId()));
			HttpSession elementSession = SessionUtil.getActiveUsers().get(requestLogoutPojo.getEncryptedId());
			
			if(elementSession!=null)
			{
				System.out.println("elementSession Not NULL-"+elementSession);
				System.out.println("Here It is from map"+elementSession.getId());
				
			}else
			{
				System.out.println("elementSession is null");
				errorMessage = "";
				responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "NA", "Falied");
				errorMessage =  gson.toJson(responseStatusPojo);
				System.out.println("errorMessage --"+errorMessage);
				return errorMessage;
			}
			if(elementSession.getAttribute("userId")!=null)
			{
				System.out.println("Oyeeeeee----"+elementSession.getAttribute("userId").toString());
				csUserDetailsMaster =  CouponServiceImpl.getInstance().getUserDetails(elementSession.getAttribute("userId").toString());
				System.out.println("Fine Here==============");
				userDeatilsPOJO = OperationUtil.getInstance().mapRequestToPojoForDetails(csUserDetailsMaster);
				userDetails = gson.toJson(userDeatilsPOJO);
				System.out.println("XXXXXXX--userDeatilsPOJO--"+userDeatilsPOJO);
				System.out.println("XXXXXXX--userDetails--"+userDetails);
				return userDetails;
			}else
			{
				errorMessage = "";
				responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "NA", "Falied");
				errorMessage =  gson.toJson(responseStatusPojo);
				System.out.println("errorMessage --"+errorMessage);
				return errorMessage;
			}
		}else
		{
			errorMessage = "";
			responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "NA", "Falied");
			errorMessage =  gson.toJson(responseStatusPojo);
			System.out.println("errorMessage --"+errorMessage);
			return errorMessage;
		}
		//http://localhost:8080/CouponSena/rest/GetCouponDetails/getUserDetails
	}
	
	@POST
	@Path("/userLogout")
	@Produces(MediaType.APPLICATION_JSON)
	public Response userLogout(RequestLogoutPojo requestLogoutPojo,@Context HttpServletRequest httpRequest, @Context HttpServletResponse httpResponse) throws Exception {
		ResponseStatusPOJO responseStatusPojo = new ResponseStatusPOJO();
		boolean flag= false;
		String sessionId = "";
		System.out.println("### userLogout --> ");
			if(requestLogoutPojo!=null)
			{
				sessionId = requestLogoutPojo.getEncryptedId();
				System.out.println("Logout sessionId--->"+sessionId);
				flag = SessionUtil.validateAndDeactiveSessionId(sessionId);
				
				if(flag)
				{
					System.out.println("### userLogout SuccessFul--> ");
					responseStatusPojo = ServiceUtil.getInstance().getResponse("200", "Logged Out Successfully", "OK");
				}else
				{
					System.out.println("Flag False");
					responseStatusPojo = ServiceUtil.getInstance().getResponse("101", "NA", "Falied");
				}
			}
			httpResponse.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
			httpResponse.setHeader("Access-Control-Allow-Origin", "*");
			httpResponse.setHeader("Vary", "Accept-Encoding");
			return Response.status(200).entity(responseStatusPojo).build();
			//http://localhost:8080/CouponSena/rest/GetCouponDetails/userLogout/{id}
	}
	
}
