package com.org.coupon.pojo;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ResponseStatusPOJO {
private String code;
private String description;
private String status;

public String getStatus() {
	return status;
}
public void setStatus(String status) {
	if(null != status)
	this.status = status.trim();
}
public String getCode() {
	return code;
}
public void setCode(String code) {
	if(null != code)
	this.code = code.trim();
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	if(null != description)
	this.description = description.trim();
}
}
