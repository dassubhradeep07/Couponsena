package com.org.coupon.pojo;

public class PopularBrandPOJO {

	private String initial;
	private String storeId;
	private String storeName;
	private String thumbnailURL;
	private String dealCount;
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getThumbnailURL() {
		return thumbnailURL;
	}
	public void setThumbnailURL(String thumbnailURL) {
		this.thumbnailURL = thumbnailURL;
	}
	public String getDealCount() {
		return dealCount;
	}
	public void setDealCount(String dealCount) {
		this.dealCount = dealCount;
	}
	
	public String getInitial() {
		return initial;
	}
	public void setInitial(String initial) {
		this.initial = initial;
	}
	@Override
	public String toString() {
		return "PopularBrandPOJO [initial=" + initial + ", storeId=" + storeId + ", storeName=" + storeName
				+ ", thumbnailURL=" + thumbnailURL + ", dealCount=" + dealCount + "]";
	}
	
	
}
