package com.org.coupon.pojo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class FilterDealTypePOJO {

	private String dealType;

	public String getDealType() {
		return dealType;
	}

	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	@Override
	public String toString() {
		return "FilterDealTypePOJO [dealType=" + dealType + "]";
	}

}
