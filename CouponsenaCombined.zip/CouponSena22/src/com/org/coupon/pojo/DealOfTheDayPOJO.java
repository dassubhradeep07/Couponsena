package com.org.coupon.pojo;

import java.util.Date;
public class DealOfTheDayPOJO {
	private Integer dotdid;
	private String title;
	private String description;
	private String url;
	private String imageurlThumbnail;
	private String imageurlLogo;
	private String availability;
	private Date rowEffDt;
	private Date rowTermDt;
	public Integer getDotdid() {
		return dotdid;
	}
	public void setDotdid(Integer dotdid) {
		this.dotdid = dotdid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getImageurlThumbnail() {
		return imageurlThumbnail;
	}
	public void setImageurlThumbnail(String imageurlThumbnail) {
		this.imageurlThumbnail = imageurlThumbnail;
	}
	public String getImageurlLogo() {
		return imageurlLogo;
	}
	public void setImageurlLogo(String imageurlLogo) {
		this.imageurlLogo = imageurlLogo;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public Date getRowEffDt() {
		return rowEffDt;
	}
	public void setRowEffDt(Date rowEffDt) {
		this.rowEffDt = rowEffDt;
	}
	public Date getRowTermDt() {
		return rowTermDt;
	}
	public void setRowTermDt(Date rowTermDt) {
		this.rowTermDt = rowTermDt;
	}
	@Override
	public String toString() {
		return "DealOfTheDayPOJO [dotdid=" + dotdid + ", title=" + title + ", description=" + description + ", url="
				+ url + ", imageurlThumbnail=" + imageurlThumbnail + ", imageurlLogo=" + imageurlLogo
				+ ", availability=" + availability + ", rowEffDt=" + rowEffDt + ", rowTermDt=" + rowTermDt + "]";
	}

	
}
