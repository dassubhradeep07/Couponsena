package com.org.coupon.pojo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SessionPOJO {
	private String sessionId;

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	@Override
	public String toString() {
		return "SessionPOJO [sessionId=" + sessionId + "]";
	}
	
	
}
