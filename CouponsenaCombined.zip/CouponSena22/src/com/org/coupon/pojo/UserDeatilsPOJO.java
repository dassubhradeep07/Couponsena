package com.org.coupon.pojo;

import java.util.Date;

public class UserDeatilsPOJO {
	private Integer userId;
	private String firstName;
	private String lastName;
	private String gender;
	private String mobileNumber;
	private String city;
	private String dob;
	private Date doa;
	private String email;
	private String addressLine1;
	private String addressLine2;
	private String state;
	private String pincode;
	private String profilePic;
	private Date lastLogin;
	private String bankName;
	private String bankBranchName;
	private String bankAccountNumber;
	private String ifsccode;
	private String beneficiaryName;
	private Date rowEffDt;
	private Date rowTermDt;
	private String password;

	public UserDeatilsPOJO() {
	}

	public UserDeatilsPOJO(String firstName, String lastName, String gender, String email, String password) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.email = email;
		this.password = password;
	}

	public UserDeatilsPOJO(String firstName, String lastName, String gender, String mobileNumber, String city, String dob,
			Date doa, String email, String addressLine1, String addressLine2, String state, String pincode,
			String profilePic, Date lastLogin, String bankName, String bankBranchName, String bankAccountNumber,
			String ifsccode, String beneficiaryName, Date rowEffDt, Date rowTermDt, String password) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.mobileNumber = mobileNumber;
		this.city = city;
		this.dob = dob;
		this.doa = doa;
		this.email = email;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.state = state;
		this.pincode = pincode;
		this.profilePic = profilePic;
		this.lastLogin = lastLogin;
		this.bankName = bankName;
		this.bankBranchName = bankBranchName;
		this.bankAccountNumber = bankAccountNumber;
		this.ifsccode = ifsccode;
		this.beneficiaryName = beneficiaryName;
		this.rowEffDt = rowEffDt;
		this.rowTermDt = rowTermDt;
		this.password = password;
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMobileNumber() {
		return this.mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDob() {
		return this.dob;
	}

	public void setDob(String dateStr) {
		this.dob = dateStr;
	}

	public Date getDoa() {
		return this.doa;
	}

	public void setDoa(Date doa) {
		this.doa = doa;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddressLine1() {
		return this.addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return this.addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return this.pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getProfilePic() {
		return this.profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public Date getLastLogin() {
		return this.lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	public String getBankName() {
		return this.bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankBranchName() {
		return this.bankBranchName;
	}

	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}

	public String getBankAccountNumber() {
		return this.bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getIfsccode() {
		return this.ifsccode;
	}

	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}

	public String getBeneficiaryName() {
		return this.beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public Date getRowEffDt() {
		return this.rowEffDt;
	}

	public void setRowEffDt(Date rowEffDt) {
		this.rowEffDt = rowEffDt;
	}

	public Date getRowTermDt() {
		return this.rowTermDt;
	}

	public void setRowTermDt(Date rowTermDt) {
		this.rowTermDt = rowTermDt;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
