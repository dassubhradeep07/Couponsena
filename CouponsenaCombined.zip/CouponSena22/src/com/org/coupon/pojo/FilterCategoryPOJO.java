package com.org.coupon.pojo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class FilterCategoryPOJO {
	private String couponCategory;

	public String getCouponCategory() {
		return couponCategory;
	}

	public void setCouponCategory(String couponCategory) {
		this.couponCategory = couponCategory;
	}

	@Override
	public String toString() {
		return "FilterCategoryPOJO [couponCategory=" + couponCategory + "]";
	}
	

}
