package com.org.coupon.pojo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RequestLogoutPojo {
	
	private String encryptedId;

	public String getEncryptedId() {
		return encryptedId;
	}

	public void setEncryptedId(String encryptedId) {
		this.encryptedId = encryptedId;
	}

	@Override
	public String toString() {
		return "RequestLogoutPojo [encryptedId=" + encryptedId + "]";
	}
	
}
