package com.org.coupon.pojo;

public class TopCategoryPOJO {

	private String CouponCategoryId;
	private String CouponCategory;
	private String dealCount;
	public String getCouponCategoryId() {
		return CouponCategoryId;
	}
	public void setCouponCategoryId(String couponCategoryId) {
		CouponCategoryId = couponCategoryId;
	}
	public String getCouponCategory() {
		return CouponCategory;
	}
	public void setCouponCategory(String couponCategory) {
		CouponCategory = couponCategory;
	}
	public String getDealCount() {
		return dealCount;
	}
	public void setDealCount(String dealCount) {
		this.dealCount = dealCount;
	}
}
