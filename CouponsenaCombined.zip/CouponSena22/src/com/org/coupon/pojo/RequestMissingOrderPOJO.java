package com.org.coupon.pojo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RequestMissingOrderPOJO {
	private String dateOfTransaction;
	private String merchantName;
	private String transactionId;
	private String totalAmountPaid;
	private String usedCouponcode;
	private String attachment;
	private String encryptedId;

	public String getDateOfTransaction() {
		return dateOfTransaction;
	}

	public void setDateOfTransaction(String dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getTotalAmountPaid() {
		return totalAmountPaid;
	}

	public void setTotalAmountPaid(String totalAmountPaid) {
		this.totalAmountPaid = totalAmountPaid;
	}

	public String getUsedCouponcode() {
		return usedCouponcode;
	}

	public void setUsedCouponcode(String usedCouponcode) {
		this.usedCouponcode = usedCouponcode;
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	public String getEncryptedId() {
		return encryptedId;
	}

	public void setEncryptedId(String encryptedId) {
		this.encryptedId = encryptedId;
	}

	@Override
	public String toString() {
		return "RequestMissingOrderPOJO [dateOfTransaction=" + dateOfTransaction + ", merchantName=" + merchantName
				+ ", transactionId=" + transactionId + ", totalAmountPaid=" + totalAmountPaid + ", usedCouponcode="
				+ usedCouponcode + ", attachment=" + attachment + ", encryptedId=" + encryptedId + "]";
	}

	

}
