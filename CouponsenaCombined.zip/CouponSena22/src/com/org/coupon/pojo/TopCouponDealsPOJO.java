package com.org.coupon.pojo;

public class TopCouponDealsPOJO {

	private String dealId;
	private String thumbnailURL;
	private String brandAndCategory;
	private String dealTitle;
	private String dealExpiaryDate;
	private String dealLink;
	private String userId;
	private String dealType;
	private String dealCode;
	private String cashback;

	public String getDealId() {
		return dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	public String getThumbnailURL() {
		return thumbnailURL;
	}

	public void setThumbnailURL(String thumbnailURL) {
		this.thumbnailURL = thumbnailURL;
	}

	public String getBrandAndCategory() {
		return brandAndCategory;
	}

	public void setBrandAndCategory(String brandAndCategory) {
		this.brandAndCategory = brandAndCategory;
	}

	public String getDealTitle() {
		return dealTitle;
	}

	public void setDealTitle(String dealTitle) {
		this.dealTitle = dealTitle;
	}

	public String getDealExpiaryDate() {
		return dealExpiaryDate;
	}

	public void setDealExpiaryDate(String dealExpiaryDate) {
		this.dealExpiaryDate = dealExpiaryDate;
	}

	public String getDealLink() {
		return dealLink;
	}

	public void setDealLink(String dealLink) {
		this.dealLink = dealLink;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDealType() {
		return dealType;
	}

	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	public String getDealCode() {
		return dealCode;
	}

	public void setDealCode(String dealCode) {
		this.dealCode = dealCode;
	}

	public String getCashback() {
		return cashback;
	}

	public void setCashback(String cashback) {
		this.cashback = cashback;
	}

	@Override
	public String toString() {
		return "TopCouponDealsPOJO [dealId=" + dealId + ", thumbnailURL=" + thumbnailURL + ", brandAndCategory="
				+ brandAndCategory + ", dealTitle=" + dealTitle + ", dealExpiaryDate=" + dealExpiaryDate + ", dealLink="
				+ dealLink + ", userId=" + userId + ", dealType=" + dealType + ", dealCode=" + dealCode + ", cashback="
				+ cashback + "]";
	}

	

}
