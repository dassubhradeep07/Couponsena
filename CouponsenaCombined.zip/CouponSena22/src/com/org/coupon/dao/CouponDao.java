package com.org.coupon.dao;

import java.util.List;

import com.org.coupon.dto.CsMetatagsMaster;
import com.org.coupon.dto.CsUserDetailsMaster;
import com.org.coupon.dto.CsUserMissingSales;
import com.org.coupon.pojo.DealOfTheDayPOJO;
import com.org.coupon.pojo.PopularBrandPOJO;
import com.org.coupon.pojo.TopCategoryPOJO;
import com.org.coupon.pojo.TopCouponDealsPOJO;

public interface CouponDao {
	
	List<TopCouponDealsPOJO> getLatestTopDealsFromDb();

	List<PopularBrandPOJO> getTopCampainsFromDb();
	
	List<PopularBrandPOJO> getAllCampainsFromDb();
	
	List<TopCategoryPOJO> getTopCategory();
	
	List<TopCategoryPOJO> getAllCategory();
	
	List<DealOfTheDayPOJO> getDodtList();
	
	CsUserDetailsMaster getUserDetails(String userId);
	
	//UserSales getUserEarnings(String userId);
	
	//boolean informMissingCoupon(CsUserMissingSales userMissingSales);
	
	boolean userRegistration(CsUserDetailsMaster userDetails);
	
	CsUserDetailsMaster userLogin(String email,String password);
	
	List<TopCouponDealsPOJO> getLatestTopDealsFromDbByCategory(String CategoryName);

	List<TopCouponDealsPOJO> getLatestTopDealsFromDbByStore(String storeName);

	List<TopCouponDealsPOJO> getLatestTopDealsFromDbByBrand(String brandName);

	boolean informMissingCoupon(CsUserMissingSales userMissingSales);
	
	CsMetatagsMaster getMetaTagInfo(String name,String type);
}
