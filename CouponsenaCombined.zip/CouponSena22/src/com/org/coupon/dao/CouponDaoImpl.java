package com.org.coupon.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.org.coupon.dto.CsDotdFlipkart;
import com.org.coupon.dto.CsFeedtableMaster;
import com.org.coupon.dto.CsMetatagsMaster;
import com.org.coupon.dto.CsUserDetailsMaster;
import com.org.coupon.dto.CsUserMissingSales;
import com.org.coupon.pojo.DealOfTheDayPOJO;
import com.org.coupon.pojo.FilterCategoryPOJO;
import com.org.coupon.pojo.FilterDealTypePOJO;
import com.org.coupon.pojo.PopularBrandPOJO;
import com.org.coupon.pojo.TopCategoryPOJO;
import com.org.coupon.pojo.TopCouponDealsPOJO;
import com.org.coupon.util.HibernateUtil;

public class CouponDaoImpl implements CouponDao {

	private static CouponDaoImpl couponDaoImpl;
	List<CsFeedtableMaster> feedTable;
	Session session;
	List<TopCouponDealsPOJO> topCouponDealsPOJOList;
	List<PopularBrandPOJO> popularBrandPOJOList;
	List<CsDotdFlipkart> csDotdFlipkartList;
	CsUserDetailsMaster userDetails;
	//UserSales userSales;

	public static CouponDaoImpl getInstance() {
		if (couponDaoImpl == null) {
			couponDaoImpl = new CouponDaoImpl();
		}
		return couponDaoImpl;
	}

	@Override
	public List<TopCouponDealsPOJO> getLatestTopDealsFromDb() {
		// TODO Auto-generated method stub
		topCouponDealsPOJOList = new ArrayList<TopCouponDealsPOJO>();
		List<TopCouponDealsPOJO> topCouponDealsPOJOListFinal = new ArrayList<TopCouponDealsPOJO>();
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		TopCouponDealsPOJO topCouponDealsPOJO = null;
		SQLQuery query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
						
			String sql = "select CouponId as dealId,StoreThumbnail as thumbnailURL,couponCategory as brandAndCategory,DealTitle as dealTitle,ExpiryDt as dealExpiaryDate,DealLink,DealType,CouponCode,IFNULL(cashback,'') as cashback from cs_feedtable_master group by StoreName Order by ExpiryDt desc limit 15";
			query = session.createSQLQuery(sql);
			query.addScalar("dealId");
			query.addScalar("thumbnailURL");
			query.addScalar("brandAndCategory");
			query.addScalar("dealTitle");
			query.addScalar("dealExpiaryDate");
			query.addScalar("dealLink");
			query.addScalar("dealType");
			query.addScalar("CouponCode");
			query.addScalar("Cashback");
			if(query.list()!=null){
				topCouponDealsPOJOList = query.list();
			}
			else{
				System.out.println("Output is null=========****************************");
			}
			if (!transaction.wasCommitted())	transaction.commit();

			Iterator itr = topCouponDealsPOJOList.iterator();
			while (itr.hasNext()) {
				Object[] obj = (Object[]) itr.next();
				topCouponDealsPOJO = new TopCouponDealsPOJO();
				topCouponDealsPOJO.setDealId(String.valueOf(obj[0]));
				topCouponDealsPOJO.setThumbnailURL(String.valueOf(obj[1]));
				topCouponDealsPOJO.setBrandAndCategory(String.valueOf(obj[2]));
				topCouponDealsPOJO.setDealTitle(String.valueOf(obj[3]));
				topCouponDealsPOJO.setDealExpiaryDate(String.valueOf(obj[4]));
				topCouponDealsPOJO.setDealLink(String.valueOf(obj[5]));
				topCouponDealsPOJO.setDealType(String.valueOf(obj[6]));
				topCouponDealsPOJO.setDealCode(String.valueOf(obj[7]));
				topCouponDealsPOJO.setCashback(String.valueOf(obj[8]));
				topCouponDealsPOJOListFinal.add(topCouponDealsPOJO);
			}
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return topCouponDealsPOJOListFinal;
	}

	@Override
	public List<PopularBrandPOJO> getTopCampainsFromDb() {
		// TODO Auto-generated method stub
		List<PopularBrandPOJO> popularBrandPOJOList = null;
		List<PopularBrandPOJO> popularBrandPOJOFinal = new ArrayList<PopularBrandPOJO>();
		session = HibernateUtil.openSession();
		PopularBrandPOJO popularBrandPOJO = null;
		Transaction transaction = null;
		SQLQuery query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			String sql = "select distinct StoreId,StoreName,StoreThumbnail,Count(DealLink) dealCount from cs_feedtable_master Group By StoreId,StoreName order By dealCount desc limit 10";
			query = session.createSQLQuery(sql);
			query.addScalar("StoreId");
			query.addScalar("StoreName");
			query.addScalar("StoreThumbnail");
			query.addScalar("dealCount");
			popularBrandPOJOList = query.list();
			// System.out.println("popularBrandPOJOList-"+popularBrandPOJOList);
			if (!transaction.wasCommitted())	transaction.commit();

			Iterator itr = popularBrandPOJOList.iterator();
			while (itr.hasNext()) {
				Object[] obj = (Object[]) itr.next();
				// System.out.println(String.valueOf(obj[0]));
				// System.out.println(String.valueOf(obj[1]));
				// System.out.println(String.valueOf(obj[2]));
				// System.out.println(String.valueOf(obj[3]));
				popularBrandPOJO = new PopularBrandPOJO();
				popularBrandPOJO.setStoreId(String.valueOf(obj[0]));
				popularBrandPOJO.setStoreName(String.valueOf(obj[1]));
				popularBrandPOJO.setThumbnailURL(String.valueOf(obj[2]));
				popularBrandPOJO.setDealCount(String.valueOf(obj[3]));
				popularBrandPOJOFinal.add(popularBrandPOJO);
			}
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return popularBrandPOJOFinal;
	}

	@Override
	public List<TopCategoryPOJO> getTopCategory() {
		// TODO Auto-generated method stub
		List<TopCategoryPOJO> topCategoryPOJOList = null;
		List<TopCategoryPOJO> topCategoryPOJOListFinal = new ArrayList<TopCategoryPOJO>();
		session = HibernateUtil.openSession();
		TopCategoryPOJO topCategoryPOJO = null;
		Transaction transaction = null;
		SQLQuery query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			String sql = "select distinct CouponCategoryId,CouponCategory,Count(DealLink) dealCount from cs_feedtable_master Group By CouponCategoryId,CouponCategory order By dealCount";
			query = session.createSQLQuery(sql);
			query.addScalar("CouponCategoryId");
			query.addScalar("CouponCategory");
			query.addScalar("dealCount");
			topCategoryPOJOList = query.list();
			// System.out.println("popularBrandPOJOList-"+popularBrandPOJOList);
			if (!transaction.wasCommitted())	transaction.commit();

			Iterator itr = topCategoryPOJOList.iterator();
			while (itr.hasNext()) {
				Object[] obj = (Object[]) itr.next();
				topCategoryPOJO = new TopCategoryPOJO();
				topCategoryPOJO.setCouponCategoryId(String.valueOf(obj[0]));
				topCategoryPOJO.setCouponCategory(String.valueOf(obj[1]));
				topCategoryPOJO.setDealCount(String.valueOf(obj[2]));
				topCategoryPOJOListFinal.add(topCategoryPOJO);
			}
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return topCategoryPOJOListFinal;
	}

	@Override
	public CsUserDetailsMaster getUserDetails(String userId) {
		// TODO Auto-generated method stub
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		int id = Integer.parseInt(userId);
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			userDetails = (CsUserDetailsMaster) session.load(CsUserDetailsMaster.class, id);
			if (userDetails != null) {
				System.out.println("Employee get called--->");
				System.out.println("first Name = " + userDetails.getFirstName());
				System.out.println("Last Name = " + userDetails.getLastName());
				System.out.println("mobile Numbner = " + userDetails.getMobileNumber());
			}
			if (!transaction.wasCommitted())	transaction.commit();
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return userDetails;
	}

	/*@Override
	public UserSales getUserEarnings(String userId) {
		// TODO Auto-generated method stub
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		int id = Integer.parseInt(userId);
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			System.out.println("aftre begin--" + id);
			userSales = (UserSales) session.load(UserSales.class, id);
			System.out.println("Employee get called--->");
			if (userSales != null) {
				System.out.println("first Name = ");
				System.out.println("userSales---" + userSales.getUserId());
			}
			if (!transaction.wasCommitted())	transaction.commit();
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return userSales;
	}*/

	@Override
	public boolean informMissingCoupon(CsUserMissingSales userMissingSales) {
		// TODO Auto-generated method stub
		boolean flag = false;
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			session.saveOrUpdate(userMissingSales);
			if (!transaction.wasCommitted())	transaction.commit();
			flag = true;
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			flag = false;
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public boolean userRegistration(CsUserDetailsMaster userDetails) {
		// TODO Auto-generated method stub
		boolean flag = false;
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			session.saveOrUpdate(userDetails);
			if (!transaction.wasCommitted())	transaction.commit();
			flag = true;
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			flag = false;
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean userUpdate(CsUserDetailsMaster userDetails) {
		// TODO Auto-generated method stub
		boolean flag = false;
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			System.out.println("userDetails Before Update--"+userDetails.toString());
			session.update(userDetails);
			if (!transaction.wasCommitted())	transaction.commit();
			flag = true;
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			flag = false;
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public CsUserDetailsMaster userLogin(String email, String password) {
		// TODO Auto-generated method stub
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		CsUserDetailsMaster csUserDetailsMaster = null;
		List<CsUserDetailsMaster> listOfUserDetails = null;
		Query query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			System.out.println("Here in Transction-------Login---->");
			System.out.println("Here in Transction-------email/password---->" + email + "/" + password);
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			query = session.createQuery("from CsUserDetailsMaster where email='" + email + "' and password='" + password + "'");
			listOfUserDetails = query.list();
			if (listOfUserDetails != null) {
				csUserDetailsMaster = listOfUserDetails.get(0);
			} else {
				System.out.println("******************listOfUserDetails is NULL");
			}
			if (!transaction.wasCommitted())	transaction.commit();
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return csUserDetailsMaster;
	}

	@Override
	public List<TopCouponDealsPOJO> getLatestTopDealsFromDbByCategory(String CategoryName) {
		// TODO Auto-generated method stub
		topCouponDealsPOJOList = new ArrayList<TopCouponDealsPOJO>();
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		Query query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			String hql = "from CsFeedtableMaster where couponCategory = '" + CategoryName + "'";
			query = session.createQuery(hql);
			feedTable = query.list();
			// feedTable = (List<Feedtable>) query.setMaxResults(10);
			topCouponDealsPOJOList = DaoUtility.setCouponDeals(feedTable);
			if (!transaction.wasCommitted())	transaction.commit();
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return topCouponDealsPOJOList;
	}

	@Override
	public List<TopCouponDealsPOJO> getLatestTopDealsFromDbByStore(String storeName) {
		// TODO Auto-generated method stub
		topCouponDealsPOJOList = new ArrayList<TopCouponDealsPOJO>();
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		Query query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			String hql = "from CsFeedtableMaster where storeName = '" + storeName + "'";
			query = session.createQuery(hql);
			feedTable = query.list();
			// feedTable = (List<Feedtable>) query.setMaxResults(10);
			topCouponDealsPOJOList = DaoUtility.setCouponDeals(feedTable);
			if (!transaction.wasCommitted())	transaction.commit();
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return topCouponDealsPOJOList;
	}

	@Override
	public List<TopCouponDealsPOJO> getLatestTopDealsFromDbByBrand(String brandName) {
		// TODO Auto-generated method stub
		topCouponDealsPOJOList = new ArrayList<TopCouponDealsPOJO>();
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		Query query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			String hql = "from cs_feedtable_master where brandName = '" + brandName + "'";
			query = session.createQuery(hql);
			feedTable = query.list();
			// feedTable = (List<Feedtable>) query.setMaxResults(10);
			topCouponDealsPOJOList = DaoUtility.setCouponDeals(feedTable);
			if (!transaction.wasCommitted())	transaction.commit();
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return topCouponDealsPOJOList;
	}

	public List<FilterDealTypePOJO> getFilterDealOptions(String storeName) {
		List<FilterDealTypePOJO> filterDealTypePOJOList = null;
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		SQLQuery query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			String sql = "select distinct DealType as dealType from cs_feedtable_master where StoreName= '" + storeName + "'";
			query = session.createSQLQuery(sql);
			query.addScalar("dealType");
			filterDealTypePOJOList = query.list();
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return filterDealTypePOJOList;
	}
	
	public List<FilterCategoryPOJO> getFilterCategoryOptions(String storeName) {
		List<FilterCategoryPOJO> filterCategoryPOJOList = null;
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		SQLQuery query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			String sql = "select distinct CouponCategory from cs_feedtable_master where StoreName= '" + storeName + "'";
			query = session.createSQLQuery(sql);
			query.addScalar("couponCategory");
			filterCategoryPOJOList = query.list();
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return filterCategoryPOJOList;
	}

	@Override
	public List<PopularBrandPOJO> getAllCampainsFromDb() {
		// TODO Auto-generated method stub
		List<PopularBrandPOJO> popularBrandPOJOList = null;
		List<PopularBrandPOJO> popularBrandPOJOFinal = new ArrayList<PopularBrandPOJO>();
		session = HibernateUtil.openSession();
		PopularBrandPOJO popularBrandPOJO = null;
		Transaction transaction = null;
		SQLQuery query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			String sql = "select distinct  SUBSTRING(ltrim(rtrim(StoreName)), 1, 1) Initials,StoreId,StoreName,StoreThumbnail,Count(DealLink) dealCount from cs_feedtable_master Group By StoreId,StoreName order By Initials";
			query = session.createSQLQuery(sql);
			query.addScalar("Initials");
			query.addScalar("StoreId");
			query.addScalar("StoreName");
			query.addScalar("StoreThumbnail");
			query.addScalar("dealCount");
			popularBrandPOJOList = query.list();
			// System.out.println("popularBrandPOJOList-"+popularBrandPOJOList);
			if (!transaction.wasCommitted())	transaction.commit();

			Iterator itr = popularBrandPOJOList.iterator();
			while (itr.hasNext()) {
				Object[] obj = (Object[]) itr.next();
				// System.out.println(String.valueOf(obj[0]));
				// System.out.println(String.valueOf(obj[1]));
				// System.out.println(String.valueOf(obj[2]));
				// System.out.println(String.valueOf(obj[3]));
				popularBrandPOJO = new PopularBrandPOJO();
				if(String.valueOf(obj[0])!=null)
				{
					popularBrandPOJO.setInitial(String.valueOf(obj[0]));
				}
				popularBrandPOJO.setStoreId(String.valueOf(obj[1]));
				popularBrandPOJO.setStoreName(String.valueOf(obj[2]));
				popularBrandPOJO.setThumbnailURL(String.valueOf(obj[3]));
				popularBrandPOJO.setDealCount(String.valueOf(obj[4]));
				popularBrandPOJOFinal.add(popularBrandPOJO);
			}
			//////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return popularBrandPOJOFinal;
	}

	@Override
	public List<TopCategoryPOJO> getAllCategory() {
		// TODO Auto-generated method stub
		List<TopCategoryPOJO> topCategoryPOJOList = null;
		List<TopCategoryPOJO> topCategoryPOJOListFinal = new ArrayList<TopCategoryPOJO>();
		session = HibernateUtil.openSession();
		TopCategoryPOJO topCategoryPOJO = null;
		Transaction transaction = null;
		SQLQuery query = null;
		try {
			if(session==null || !session.isOpen())
			{
				System.out.println("*****abcd*******");
				System.out.println("Session is open"+session.isOpen());
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			System.out.println("transaction is active????********===>"+transaction.isActive());
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			String sql = "select distinct CouponCategoryId,CouponCategory,Count(DealLink) dealCount from cs_feedtable_master Group By CouponCategoryId,CouponCategory order By CouponCategory";
			System.out.println("***2****transaction is active????********===>"+transaction.isActive());
			query = session.createSQLQuery(sql);
			query.addScalar("CouponCategoryId");
			query.addScalar("CouponCategory");
			query.addScalar("dealCount");
			topCategoryPOJOList = query.list();
			// System.out.println("popularBrandPOJOList-"+popularBrandPOJOList);
			if (!transaction.wasCommitted()) transaction.commit();

			Iterator itr = topCategoryPOJOList.iterator();
			while (itr.hasNext()) {
				Object[] obj = (Object[]) itr.next();
				topCategoryPOJO = new TopCategoryPOJO();
				topCategoryPOJO.setCouponCategoryId(String.valueOf(obj[0]));
				topCategoryPOJO.setCouponCategory(String.valueOf(obj[1]));
				topCategoryPOJO.setDealCount(String.valueOf(obj[2]));
				topCategoryPOJOListFinal.add(topCategoryPOJO);
			}
			//////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
			
		return topCategoryPOJOListFinal;
	}

	@Override
	public CsMetatagsMaster getMetaTagInfo(String name, String type) {
		ArrayList<CsMetatagsMaster> csMetatagsMasterList = null;
		session = HibernateUtil.openSession();
		CsMetatagsMaster csMetatagsMaster = null;
		Transaction transaction = null;
		SQLQuery query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
			String sql = "select Name,Type,Title,Description,Keywords from cs_metatags_master where Name = '"+name+"' and Type = '"+type+"'";
			query = session.createSQLQuery(sql);
			csMetatagsMasterList = (ArrayList<CsMetatagsMaster>) query.list();
			Iterator itr = csMetatagsMasterList.iterator();
			while (itr.hasNext()) {
				Object[] obj = (Object[]) itr.next();
				csMetatagsMaster = new CsMetatagsMaster();
				csMetatagsMaster.setName(String.valueOf(obj[0]));
				csMetatagsMaster.setType(String.valueOf(obj[1]));
				csMetatagsMaster.setTitle(String.valueOf(obj[2]));
				csMetatagsMaster.setDescription(String.valueOf(obj[3]));
				csMetatagsMaster.setKeywords(String.valueOf(obj[4]));
			}
				System.out.println("csMetatagsMaster--"+csMetatagsMaster.getName()+"--"+csMetatagsMaster.getType()+"--"+csMetatagsMaster.getTitle());
			
			////////HibernateUtil.closeSession(session);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return csMetatagsMaster;
	}
	

	public CsUserDetailsMaster GetUserByDetails(int userId)
	{
		CsUserDetailsMaster csUserDetailsMaster = null;
		session = HibernateUtil.openSession();
		
		Transaction transaction = null;
		//Query query = null;
		try {
			if(session!=null || session.isOpen())
			{
				session = HibernateUtil.openSession();
			}
			transaction = session.beginTransaction();
			if(!transaction.isActive())
			{
				transaction.begin();
			}
		    System.out.println("userId--"+userId);
			csUserDetailsMaster =  (CsUserDetailsMaster) session.get(CsUserDetailsMaster.class, userId);
			if (!transaction.wasCommitted())	transaction.commit();
			////////HibernateUtil.closeSession(session);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return csUserDetailsMaster;
	}

	@Override
	public List<DealOfTheDayPOJO> getDodtList() {
		session = HibernateUtil.openSession();
		Transaction transaction = null;
		SQLQuery query = null;
		List<CsDotdFlipkart> csDotdFlipkartList = null;
		List<DealOfTheDayPOJO> dealOfTheDayList = new ArrayList<DealOfTheDayPOJO>();
		DealOfTheDayPOJO dealOfTheDayPOJO = null;
		try {
				if(session!=null || session.isOpen())
				{
					session = HibernateUtil.openSession();
					
				}
				transaction = session.beginTransaction();
				if(!transaction.isActive())
				{
					transaction.begin();
				}
				String sql = "select Title,Description,url,imageurl_thumbnail,imageurl_logo,availability from cs_dotd_flipkart limit 5";
				query = session.createSQLQuery(sql);
				query.addScalar("Title");
				query.addScalar("Description");
				query.addScalar("url");
				query.addScalar("imageurl_thumbnail");
				query.addScalar("imageurl_logo");
				query.addScalar("availability");
				csDotdFlipkartList = query.list();
				// System.out.println("popularBrandPOJOList-"+popularBrandPOJOList);
				if (!transaction.wasCommitted())	transaction.commit();

				Iterator itr = csDotdFlipkartList.iterator();
				while (itr.hasNext()) {
					Object[] obj = (Object[]) itr.next();
					// System.out.println(String.valueOf(obj[0]));
					// System.out.println(String.valueOf(obj[1]));
					// System.out.println(String.valueOf(obj[2]));
					// System.out.println(String.valueOf(obj[3]));
					dealOfTheDayPOJO = new DealOfTheDayPOJO();
					dealOfTheDayPOJO.setTitle(String.valueOf(obj[0]));
					dealOfTheDayPOJO.setDescription(String.valueOf(obj[1]));
					dealOfTheDayPOJO.setUrl(String.valueOf(obj[2]));
					dealOfTheDayPOJO.setImageurlThumbnail(String.valueOf(obj[3]));
					dealOfTheDayPOJO.setImageurlLogo(String.valueOf(obj[4]));
					dealOfTheDayPOJO.setAvailability(String.valueOf(obj[5]));
					dealOfTheDayList.add(dealOfTheDayPOJO);
				}
		}catch(Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dealOfTheDayList;
	}

}
