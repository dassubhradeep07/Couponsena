package com.org.coupon.dao;

import java.util.ArrayList;
import java.util.List;

import com.org.coupon.dto.CsFeedtableMaster;
import com.org.coupon.pojo.FilterDealTypePOJO;
import com.org.coupon.pojo.PopularBrandPOJO;
import com.org.coupon.pojo.TopCouponDealsPOJO;

public class DaoUtility {
	
	static TopCouponDealsPOJO topCouponDealsPOJO;
	static PopularBrandPOJO popularBrandPOJO = new PopularBrandPOJO();
	
	public static List<TopCouponDealsPOJO> setCouponDeals(List<CsFeedtableMaster> feedTable) {
		
		List<TopCouponDealsPOJO> topCouponDealsPOJOList = new ArrayList<TopCouponDealsPOJO>();
		try
		{
			if(feedTable==null)
			{
				System.out.println("feedTable is null");
			}else
			{
				System.out.println("feedTable size - "+feedTable.size());
			}
			for(CsFeedtableMaster feeds : feedTable)
			{
				topCouponDealsPOJO = new TopCouponDealsPOJO();
				topCouponDealsPOJO.setDealId(feeds.getCouponId());
				topCouponDealsPOJO.setBrandAndCategory(feeds.getStoreName()+" - "+feeds.getCouponCategory());
				topCouponDealsPOJO.setDealCode(feeds.getCouponCode());
				topCouponDealsPOJO.setDealExpiaryDate(feeds.getExpiryDt().toString());
				topCouponDealsPOJO.setDealLink(feeds.getDealLink());
				topCouponDealsPOJO.setDealTitle(feeds.getDealTitle());
				topCouponDealsPOJO.setDealType(feeds.getDealType());
				topCouponDealsPOJO.setThumbnailURL(feeds.getStoreThumbnail());
				topCouponDealsPOJO.setUserId("");
				
				topCouponDealsPOJOList.add(topCouponDealsPOJO);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return topCouponDealsPOJOList;
	}
	
	public static List<PopularBrandPOJO> setCampaignList(List<PopularBrandPOJO> result) {
		
		return null;
	}
	
	
	public static List<FilterDealTypePOJO> getDealTypeFilter(String store)
	{
		return null;
	}
	
}
