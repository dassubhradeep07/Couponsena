package com.org.coupon.service;

import java.util.List;

import com.org.coupon.dao.CouponDaoImpl;
import com.org.coupon.dto.CsMetatagsMaster;
import com.org.coupon.dto.CsUserDetailsMaster;
import com.org.coupon.dto.CsUserMissingSales;
import com.org.coupon.pojo.DealOfTheDayPOJO;
import com.org.coupon.pojo.PopularBrandPOJO;
import com.org.coupon.pojo.RequestLoginPOJO;
import com.org.coupon.pojo.RequestMissingOrderPOJO;
import com.org.coupon.pojo.RequestUserRegistrationPOJO;
import com.org.coupon.pojo.TopCategoryPOJO;
import com.org.coupon.pojo.TopCouponDealsPOJO;
import com.org.coupon.util.OperationUtil;

public class CouponServiceImpl implements CouponService{
	
	private static CouponServiceImpl couponServiceImpl = null;
	CsUserDetailsMaster userdetails = null;
	//UserSales userSales = null;
	CsUserMissingSales userMissingSales = null;
	
	public static CouponServiceImpl getInstance()
	{
		if(couponServiceImpl==null)
		{
			couponServiceImpl = new CouponServiceImpl();
		}
		return couponServiceImpl;
	}

	@Override
	public List<TopCouponDealsPOJO> getLatestTopDeals() {
		List<TopCouponDealsPOJO> topdeals = CouponDaoImpl.getInstance().getLatestTopDealsFromDb();
		return topdeals;
		// TODO Auto-generated method stub
	}

	@Override
	public List<PopularBrandPOJO> getTopCampains() {
		List<PopularBrandPOJO> topCampaings = CouponDaoImpl.getInstance().getTopCampainsFromDb();
		return topCampaings;
		// TODO Auto-generated method stub
	}

	@Override
	public CsUserDetailsMaster getUserDetails(String userId) {
		// TODO Auto-generated method stub
		userdetails = CouponDaoImpl.getInstance().getUserDetails(userId);
		return userdetails;
	}

	/*@Override
	public UserSales getUserEarnings(String userId) {
		// TODO Auto-generated method stub
		userSales = CouponDaoImpl.getInstance().getUserEarnings(userId);
		return userSales;
	}*/

	@Override
	public boolean informMissingCoupon(RequestMissingOrderPOJO requestMissingOrderPojo,String userId) {
		// TODO Auto-generated method stub
		boolean flag= false;
		try
		{
			userMissingSales = OperationUtil.getInstance().mapPojoToTable(requestMissingOrderPojo,userId);
			flag = CouponDaoImpl.getInstance().informMissingCoupon(userMissingSales);
		}catch(Exception e)
		{
			flag= false;
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public boolean userRegistration(RequestUserRegistrationPOJO requestUserRegistrationPojo) {
		// TODO Auto-generated method stub
			boolean flag = false;
			CsUserDetailsMaster userDetails = OperationUtil.getInstance().mapRequestToPojoForRegistration(requestUserRegistrationPojo);
		if(userDetails!=null)
		{
			System.out.println("userDetails in userRegistration"+userDetails);
			flag = CouponDaoImpl.getInstance().userRegistration(userDetails);
		}else
		{
			flag =false;
		}
		return flag;
	}
	
	public boolean userUpdate(RequestUserRegistrationPOJO requestUserRegistrationPojo,int userId) {
		// TODO Auto-generated method stub
			boolean flag = false;
			CsUserDetailsMaster userDetails = CouponDaoImpl.getInstance().GetUserByDetails(userId);
		if(userDetails!=null)
		{
			System.out.println("userDetails in userUpdate Before mapping--"+userDetails);
			OperationUtil.getInstance().mapRequestToPojoForUpdate(requestUserRegistrationPojo,userDetails);
			System.out.println("userDetails in userUpdate Aftre Reutn--"+userDetails);
			flag = CouponDaoImpl.getInstance().userUpdate(userDetails);
		}else
		{
			flag =false;
		}
		return flag;
	}

	@Override
	public CsUserDetailsMaster userLogin(RequestLoginPOJO requestLoginPOJO) {
		// TODO Auto-generated method stub
		CsUserDetailsMaster csUserDetailsMaster = null;
		String email = requestLoginPOJO.getEmail();
		//String password = OperationUtil.getInstance().decryptPassword(requestLoginPOJO.getPassword());
		String password = requestLoginPOJO.getPassword();
		if(email!=null && !email.trim().equals("") && password !=null && !password.trim().equals(""))
		{
			csUserDetailsMaster = CouponDaoImpl.getInstance().userLogin(email, password);
		}
		return csUserDetailsMaster;
	}
	
	public CsUserDetailsMaster userLogin(String email,String password) {
		// TODO Auto-generated method stub
		CsUserDetailsMaster userDetails = null;
		//String password = OperationUtil.getInstance().decryptPassword(requestLoginPOJO.getPassword());
		if(!email.trim().equals("") && !password.trim().equals(""))
		{
			userDetails = CouponDaoImpl.getInstance().userLogin(email, password);
		}
		return userDetails;
	}

	@Override
	public List<TopCouponDealsPOJO> getDealsByCategory(String categoryName) {
		// TODO Auto-generated method stub
		List<TopCouponDealsPOJO> topdeals = CouponDaoImpl.getInstance().getLatestTopDealsFromDbByCategory(categoryName);
		return topdeals;
	}
	
	@Override
	public List<TopCouponDealsPOJO> getDealsByStore(String storeName) {
		// TODO Auto-generated method stub
		List<TopCouponDealsPOJO> topdeals = CouponDaoImpl.getInstance().getLatestTopDealsFromDbByStore(storeName);
		return topdeals;
	}

	@Override
	public List<TopCouponDealsPOJO> getDealsByBrand(String brandName) {
		// TODO Auto-generated method stub
		List<TopCouponDealsPOJO> topdeals = CouponDaoImpl.getInstance().getLatestTopDealsFromDbByBrand(brandName);
		return topdeals;
	}

	@Override
	public List<TopCategoryPOJO> getTopCategory() {
		// TODO Auto-generated method stub
		List<TopCategoryPOJO> topCategory = CouponDaoImpl.getInstance().getAllCategory();
		return topCategory;
	}

	@Override
	public List<PopularBrandPOJO> getAllCampains() {
		// TODO Auto-generated method stub
		List<PopularBrandPOJO> allCampaings = CouponDaoImpl.getInstance().getAllCampainsFromDb();
		return allCampaings;
	}

	@Override
	public List<TopCategoryPOJO> getAllCategory() {
		// TODO Auto-generated method stub
		List<TopCategoryPOJO> allCategory = CouponDaoImpl.getInstance().getAllCategory();
		return allCategory;
	}

	@Override
	public CsMetatagsMaster getMetaTagInfo(String name,String type) {
		// TODO Auto-generated method stub
		CsMetatagsMaster csMetatagsMaster = CouponDaoImpl.getInstance().getMetaTagInfo(name, type);
		return csMetatagsMaster;
	}

	@Override
	public List<DealOfTheDayPOJO> getDealOfTheDay() {
		// TODO Auto-generated method stub
		List<DealOfTheDayPOJO> csDotdList = CouponDaoImpl.getInstance().getDodtList();
		return csDotdList;
	}
}
