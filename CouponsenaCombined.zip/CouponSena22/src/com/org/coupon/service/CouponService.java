package com.org.coupon.service;

import java.util.List;

import com.org.coupon.dto.CsMetatagsMaster;
import com.org.coupon.dto.CsUserDetailsMaster;
import com.org.coupon.pojo.DealOfTheDayPOJO;
import com.org.coupon.pojo.PopularBrandPOJO;
import com.org.coupon.pojo.RequestLoginPOJO;
import com.org.coupon.pojo.RequestMissingOrderPOJO;
import com.org.coupon.pojo.RequestUserRegistrationPOJO;
import com.org.coupon.pojo.TopCategoryPOJO;
import com.org.coupon.pojo.TopCouponDealsPOJO;

public interface CouponService {
	List<TopCouponDealsPOJO> getLatestTopDeals();

	List<PopularBrandPOJO> getTopCampains();
	
	List<PopularBrandPOJO> getAllCampains();
	
	List<TopCategoryPOJO> getTopCategory();
	
	List<DealOfTheDayPOJO> getDealOfTheDay();
	
	List<TopCategoryPOJO> getAllCategory();
	
	CsUserDetailsMaster getUserDetails(String userId);
	
	//CsUserDetailsMaster getUserEarnings(String userId);
	
	boolean userRegistration(RequestUserRegistrationPOJO requestUserRegistrationPojo);
	
	CsUserDetailsMaster userLogin(RequestLoginPOJO requestLoginPOJO);
	
	List<TopCouponDealsPOJO> getDealsByCategory(String categoryName);
	
	List<TopCouponDealsPOJO> getDealsByStore(String Store);

	List<TopCouponDealsPOJO> getDealsByBrand(String brandName);
	
	CsMetatagsMaster getMetaTagInfo(String name,String type);

	boolean informMissingCoupon(RequestMissingOrderPOJO requestMissingOrderPojo, String userId);
}
