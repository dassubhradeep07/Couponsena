﻿var clicked = true;
function showhide() {
	var div = document.getElementById("two");
	if (div.style.display !== "none") {
		div.style.display = "none";
	} else {
		div.style.display = "block";
		document.getElementById("two1").style.display = "none";
		document.getElementById("two2").style.display = "none";
	}
}

function showhide1() {
	var div = document.getElementById("two1");
	if (div.style.display !== "none") {
		div.style.display = "none";
	} else {
		div.style.display = "block";
		document.getElementById("two").style.display = "none";
		document.getElementById("two2").style.display = "none";
	}
}
function showhide2() {
	var div = document.getElementById("two2");
	if (div.style.display !== "none") {
		div.style.display = "none";
	} else {
		div.style.display = "block";
		document.getElementById("two").style.display = "none";
		document.getElementById("two1").style.display = "none";
	}
}

/** ****************************************************************************** */

/*
 * $(document).ready(function() { console.log("Calling This
 * Script1111111111111111------>>>>"); size_div = $("#CouponDiv div").size();
 * console.log("Calling This Script2222222222222222------>>>>"); x = 3;
 * $('#CouponDiv div:lt(' + x + ')').show(); $('#loadMore').click(function() { x =
 * (x + 5 <= size_div) ? x + 5 : size_div; $('#CouponDiv div:lt(' + x +
 * ')').show(); }); $('#showLess').click(function() { x = (x - 5 < 0) ? 3 : x -
 * 5; $('#CouponDiv div').not(':lt(' + x + ')').hide(); }); });
 */

function loadMoreLess() {
	console.log("Calling This Script1111111111111111------>>>>");
	size_div = $("#rcorners2 div").size();
	console.log("Calling This Script2222222222222222------>>>>" + size_div);
	x = 36;
	$('#rcorners2 div:lt(' + x + ')').show();
	console.log("Calling This Script2222222222222222------here >>>>");
	$('#loadMore').click(function() {
		x = (x + 5 <= size_div) ? x + 5 : size_div;
		console.log("Calling This Script X is------loadMore >>>>" + x);
		$('#rcorners2 div:lt(' + x + ')').show();
	});
	$('#showLess').click(function() {
		x = (x - 5 < 0) ? 3 : x - 5;
		console.log("Calling This Script X is------showLess >>>>" + x);
		$('#rcorners2 div').not(':lt(' + x + ')').hide();
	});
}