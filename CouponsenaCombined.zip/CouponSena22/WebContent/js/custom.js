$(document).ready(function () {

    // For tab script //
    $(".tab-content .tab-pane").hide();
    $(".tab-content .tab-pane:first").show();

    $(".maintab-m li a").click(function () {
        //alert(22)
        $(".maintab-m li").removeClass("active");
        $(this).parent(this).toggleClass("active");
        var getid = $(this).attr("name");
        //var finalanswer=getid.split("#");
        var str = getid;
        var currentid = ".tab-content #" + str;
        //alert(currentid);
        $(".tab-content .tab-pane").fadeOut(0);
        $(currentid).fadeIn(200);
    })
    // end tab script //
})

///////////// inner tabs ///////////////
$(document).ready(function () {

    // For tab script //
    $(".innr-tab-content .tab-pane2").hide();
    $(".innr-tab-content .tab-pane2:first").show();

    $(".innr-tabs li a").click(function () {
        //alert(22)
        $(".innr-tabs li").removeClass("active");
        $(this).parent(this).toggleClass("active");
        var getid = $(this).attr("name");
        //var finalanswer=getid.split("#");
        var str = getid;
        var currentid = ".innr-tab-content #" + str;
        //alert(currentid);
        $(".innr-tab-content .tab-pane2").fadeOut(0);
        $(currentid).fadeIn(200);
    })
    // end tab script //

    if (document.getElementById("content_content_hf_QryStr") != null) {
        var QryStr = document.getElementById("content_content_hf_QryStr").value;
        if (QryStr == 'local') {
            $(".innr-tab-content .tab-pane2").show();
            $(".innr-tab-content .tab-pane2:first").hide();
        }
    }
})



$(document).ready(function () {

    // For tab script //
    $(".tab-content .tab-pane").hide();
    $(".tab-content .tab-pane:first").show();

    $(".maintab-m li a").click(function () {

        //alert(22)
        $(".maintab-m li").removeClass("active");
        $(this).parent(this).toggleClass("active");
        var getid = $(this).attr("name");
        //var finalanswer=getid.split("#");
        var str = getid;
        var currentid = ".tab-content #" + str;
        //alert(currentid);
        $(".tab-content .tab-pane").fadeOut(0);
        $(currentid).fadeIn(200);
    })
    // end tab script //
})

///////////// inner tabs ///////////////
$(document).ready(function () {

    // For tab script //
    $(".innr-tab-content .tab-pane2").hide();
    $(".innr-tab-content .tab-pane2:first").show();

    $(".innr-tabs li a").click(function () {

        //alert(22)
        $(".innr-tabs li").removeClass("active");
        $(this).parent(this).toggleClass("active");
        var getid = $(this).attr("name");
        //var finalanswer=getid.split("#");
        var str = getid;
        var currentid = ".innr-tab-content #" + str;
        //alert(currentid);
        $(".innr-tab-content .tab-pane2").fadeOut(0);
        $(currentid).fadeIn(200);
    })
    // end tab script //
})

///////////// inner tabs paysec ///////////////
$(document).ready(function () {

    // For tab script //
    $(".innr-tab-content.pay2cntsec .tab-pane3").hide();
    $(".innr-tab-content.pay2cntsec .tab-pane3:first").show();

    $(".innr-tabs li a").click(function () {

        //alert(22)
        $(".innr-tabs li").removeClass("active");
        $(this).parent(this).toggleClass("active");
        var getid = $(this).attr("name");
        //var finalanswer=getid.split("#");
        var str = getid;
        var currentid = ".innr-tab-content.pay2cntsec #" + str;
        //alert(currentid);
        $(".innr-tab-content.pay2cntsec .tab-pane3").fadeOut(0);
        $(currentid).fadeIn(200);
    })
    // end tab script //
})	