couponControllers.controller('userAccountController',function($scope, $location,$http){
	
	$scope.$on('$routeChangeSuccess', function() {
			$scope.getCouponHomeDetails();
			/*$('#image3').css(
					"display", "block");
			$('#table').css(
					"display", "none");*/
	});
	
	$scope.getCouponHomeDetails = function() {/*
			
			$http.get('http://localhost:8080/CouponSena/rest/GetCouponDetails/getHomeDetails')
			.success(function(data, status, headers, config) {
				
				$scope.myData=data;
			//	var obj = eval("(" + $scope.myData + ')');				
				console.log("allDealsObject Object:--"+$scope.myData);
				
				
				
				
			}).error(function(data) {
				$scope.alerts.push("sorry!!! connection error, please try after some time");
				$timeout(function() {$scope.alerts.splice(0,1);}, 5000);
				//$('#image1').css("display", "none");
			});
		console.log("Inside allDealsController function");
	*/};
});