var couponControllers = angular.module('couponControllers',[]);

couponControllers.controller('couponHomeController',function($scope,$location,$http, $q, homedeatilsService, menuService){
	
	$scope.coupons = [];
	$scope.brands = [];
	$scope.categories = [];
	$scope.loginid = "";
	$scope.encryptedid = "";
	$scope.finalSessionId = "";
	
	
	/*********************************Entry Point Start*********************************/
	
	$scope.$on('$routeChangeSuccess', function() {
			console.log("Entry Point--------------------------------------->");
			//console.log("$scope.encryptedid----"+$scope.encryptedid);
			console.log("###document.cookie Staring----"+document.cookie);
			//console.log("###getCookie(document.cookie)----"+getCookie(document.cookie));
			if(getCookie(document.cookie)!="")
			{
				console.log("###Cookie Present ---->>");
				$finalSessionId = getCookie(document.cookie);
				console.log("###$finalSessionId----"+$finalSessionId);
				document.getElementById("prelogin").children[0].style.display = "none";
				document.getElementById("postlogin").style.display = "block";
				console.log("###User Option display Done---->>");
			}
			else if(getCookie(document.cookie)=="" && document.getElementById("logoutId").value =="LogIn")
			{
				console.log("###Cookie Abnsent ---->>");
				$scope.getLoginDetails();
				document.getElementById("logoutId").value ="";
				/*$scope.getCouponHomeDetails();
				loadData();*/
			}
			
			if (document.getElementById("logoutId").value =="LogOut" && getCookie(document.cookie)!="")
			{
				console.log("###LogOut Called In Controller---->>");
				$scope.logoutFunction();
				document.getElementById("prelogin").children[0].style.display = "block";
				document.getElementById("postlogin").style.display = "none";
				/*$scope.getCouponHomeDetails();
				loadData();*/
			}
			$scope.getCouponHomeDetails();
			loadData();
			console.log("End Point--------------------------------------->");
	});
	
	/*********************************Entry Point End*********************************/
	
	
	function loadData() {
		var promisehome = homedeatilsService.get();
		var promisecategories = menuService.get();
		console.log("promisehome"+promisehome);
		$scope.combineResult = $q.all([ promisehome, promisecategories ]).then(
						function(resp) {
							console.log("Is It Calling------>>>");
							console.log(resp);
							$scope.coupons = resp[0].data.value[0].coupon;
							$scope.brands = resp[0].data.value[1].brand;
							$scope.categories = resp[1].data.value[0].category;
							console.log(resp);
						});
				};
	
	
/*********************************Login Function Start*********************************/
	$scope.getLoginDetails = function(){
				var username = document.getElementById("username").value;
				console.log("username::"+username);
				var password = document.getElementById("password").value;
				console.log("password::"+password);
				$scope.jsonObject = {"email" : username,
									"password": password
							  	   };
				console.log("Login Function------------------------>");
				
				$http({url : 'http://localhost:8080/CouponSena/rest/GetCouponDetails/userLogin',
						data : $scope.jsonObject,
						method : 'POST'
				}).success(function(data) {
					//$scope.alerts.push({ msg: data.status});
					$('#exampleModal').css("display", "none");
					console.log(data);
					if( data.status == "OK"){
						console.log("description"+data.description);
						if(data.description!=null && data.description!="")
							{
								$encryptedid = data.description;
								//console.log("$encryptedid After Login True---"+$encryptedid);
								document.cookie = "sessionId="+$encryptedid+";path=/;";
								//console.log("In **If** document.cookie After new Id Generate---->"+document.cookie);
								document.getElementById("prelogin").children[0].style.display = "none";
								document.getElementById("postlogin").style.display = "block";
								//alert("Successfully logged in");
							}
						document.getElementById("username").value= "";
						document.getElementById("password").value= "";
						
					}
				}).error(function(err) {
					$scope.alerts.push({type: data.messageColour, msg: data.messageValue});
					$('#image1').css("display", "none");
				});
				
	};
	
	/*********************************Login Function End*********************************/
	
	
	
	/*********************************Get Home Details Start*********************************/
	
	$scope.getCouponHomeDetails = function() {
			$http.get('http://localhost:8080/CouponSena/rest/GetCouponDetails/getHomeDetails')
			.success(function(data, status, headers, config) {
				$scope.myCoupons=data.value[0].coupon;
				$scope.myBrands=data.value[1].brand;
				//console.log("getCouponDetails Object:--"+$scope.myCoupons);
				//console.log("brands: "+$scope.myBrands);
			});
	};
	
	/*********************************Get Home Details End*********************************/
	
	
	
	/*********************************Get Cookie Name Start*********************************/
	function getCookie(cname) {
	    var name = cname + "=";
	    var ca = document.cookie.split(';');
	    for (i = 0; i < ca.length; i++)
	    	{
		    	console.log("ca[i]"+i+":"+ca[i]);
		        if (ca[i].includes("sessionId")) {
		        	//console.log("Final Session Value As SessionId : "+ca[0].substring(10,ca[0].length));
		        	console.log("######GOT IT########");
		        	return ca[i].substring(10,ca[i].length);
	        }
	}
	    return "";
	};
	/*********************************Get Cookie Name End*********************************/
	
	
	
	/*********************************Remove Cookie Start*********************************/
	function eraseCookie(c_name) {
		document.cookie = c_name+ '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;path=/;';
		console.log("Cookie c_name Disable Done----"+c_name)
		console.log("document.cookie now After Disable Done----"+document.cookie);
	};
	/*********************************Remove Cookie End*********************************/
		
	
	
	/*********************************On Hover Login/User Navigation Start*********************************/
	$scope.hoverIn = function(){
		//$(".dropdown-menu").hoverEdit = true;
		console.log("hoverInnnn----")
		$(".dropdown-menu").show();
	};

	$scope.hoverOut = function(){
	   // $(".dropdown-menu").hoverEdit = false;
	    $(".dropdown-menu").hide();
	};
	/*********************************On Hover Login/User Navigation End*********************************/
	
	
	/*************************************Logout Start*********************************/
	$scope.logoutFunction = function()
	//function yourFunction()
	{
		console.log("XXXXXXXXXXXXXX LogOut Function Called XXXXXXXXXXXXXXXXXXX");
		console.log("getCookie(document.cookie) in LogOut Function--"+document.cookie);
		var abc = getCookie(document.cookie);
		console.log("getCookie(document.cookie)==abc=="+abc);
		$scope.jsonObject = {
			"encryptedId" : abc
		};

		$http(
				{
					url : 'http://localhost:8080/CouponSena/rest/GetCouponDetails/userLogout',
					data : $scope.jsonObject,
					method : 'POST'
				}).success(function(data) {
			//$scope.alerts.push({ msg: data.status});
			$('#exampleModal').css("display", "none");
			console.log(data);
			if (data.status == "OK") {
				//alert("Successfully logged Out Start");
				eraseCookie(abc);
				 $(".dropdown-menu").hide();
				 document.getElementById("logoutId").value ="";
				 document.getElementById("prelogin").children[0].style.display = "block";
				 document.getElementById("postlogin").style.display = "none";
				//alert("Successfully logged Out");
			}else
				{
					console.log("LogOut Failed");
				}
			$('#image1').css("display", "none");
		}).error(function(err) {
			$scope.alerts.push({
				type : data.messageColour,
				msg : data.messageValue
			});
			$('#image1').css("display", "none");
		});
		console.log("XXXXXXXXXXXXXX LogOut Function Called EndXXXXXXXXXXXXXXXXXXX");
	};
	/*************************************Logout End*********************************/
	
	
});