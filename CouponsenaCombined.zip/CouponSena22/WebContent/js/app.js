var app = angular.module('couponApp',
		[ 'ngRoute', 'couponControllers']);

app.config([ '$routeProvider', function($routeProvider) {
	$routeProvider.when('/home', {
		templateUrl : 'partials/couponHome.html',
		controller : 'couponHomeController'
	}).when('/userAccount', {
		templateUrl : 'userAccount.html',
		controller : 'userAccountController'
	}).otherwise({
		redirectTo : '/home'
	});
} ]);

app
.service(
		'homedeatilsService',
		function($http) {
			this.get = function() {
				var response = $http
						.get("http://localhost:8080/CouponSena/rest/GetCouponDetails/getHomeDetails");
				return response;
			};
		});

app
.service(
		'menuService',
		function($http) {
			this.get = function() {
				var response = $http
						.get("http://localhost:8080/CouponSena/rest/GetCouponDetails/getSearchFilter");
				return response;
			};
		});


app.controller('loginController', [ '$scope','$http', '$location', '$route',
                          		function($scope,$http, $location, $route, $timeout) {
                          			
                          			/*
                          			 * Will be triggered when uses clicks search button. It identifies
                          			 * the current selected tab and reloads/redirects to the
                          			 * corresponding page.
                          			 */
									
									$scope.hoverIn = function(){
										//$(".dropdown-menu").hoverEdit = true;
										console.log("hoverInnnn----")
										$(".dropdown-menu").show();
									};
								
									$scope.hoverOut = function(){
									   // $(".dropdown-menu").hoverEdit = false;
									    $(".dropdown-menu").hide();
									};
									
									
                          			$scope.logDetails = function() {
                          				if(document.getElementById("username").value==""){
                          					alert("please enter username");
                          				}
                          				if(document.getElementById("password").value==""){
                          					alert("please enter password!");
                          				}
                          				/*if (currentPage === "profile") {
                          					$location.url('/profile');
                          				}
                          				if (currentPage === "employee") {
                          					$location.url('/employee');
                          				}
                          				if (currentPage === "news") {
                          					$location.url('/news');
                          				}
                          				if (currentPage === "finance") {
                          					$location.url('/finance');
                          				}*/
                          				$route.reload();
                          			};
                          			

                          		} ]);