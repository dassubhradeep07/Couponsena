package com.org.coupon.client.Utility;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import javax.xml.soap.SOAPMessage;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.org.coupon.dto.CsCampaignDetailsVcm;
import com.org.coupon.dto.CsCategoryDetailsVcm;
import com.org.coupon.dto.CsDotdFlipkart;
import com.org.coupon.dto.CsFeedtableDgm;
import com.org.coupon.dto.CsFeedtableFlipkart;
import com.org.coupon.dto.CsFeedtableVcm;
import com.org.coupon.dto.CsSaleFlipkart;
import com.org.coupon.dto.CsSaleVcm;

public class ClientUtility {

	private static ClientUtility clientUtility = null;;
	
	public static ClientUtility getInstance()
	{
		if(clientUtility== null)
		{
			clientUtility = new ClientUtility();
		}
		return clientUtility;
	}
	
		//For FeedTable For Flipkart From Rest service
		public CsFeedtableFlipkart mapResponseToFeedForFlipkart(JSONObject jsonobject)
		{
			CsFeedtableFlipkart csFeedtableFlipkart = new CsFeedtableFlipkart();
			try
			{
				csFeedtableFlipkart.setStartTime(getTimeMillsToDate(jsonobject.getString("startTime")));
				csFeedtableFlipkart.setEndTime(getTimeMillsToDate(jsonobject.getString("endTime")));
				csFeedtableFlipkart.setTitle(jsonobject.getString("title"));
				csFeedtableFlipkart.setDescription(jsonobject.getString("description"));
				csFeedtableFlipkart.setUrl(jsonobject.getString("url"));
				csFeedtableFlipkart.setCategory(jsonobject.getString("category"));
				csFeedtableFlipkart.setAvailability(jsonobject.getString("availability"));
				csFeedtableFlipkart.setRowEffDt(getCurrentDateOnly());
				
				//System.out.println("#feedtable-"+feedtable.toString());
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			return csFeedtableFlipkart;
		}
		
		
			//For Sale For Flipkart From Rest service
				public CsSaleFlipkart mapResponseToSaleForFlipkart(JSONObject jsonobject)
				{
					JSONObject jobj = null;
					JSONObject jobjComm = null;
					CsSaleFlipkart csSaleFlipkart = new CsSaleFlipkart();
					try
					{
						jobj = jsonobject.getJSONObject("sales");
						jobjComm = jsonobject.getJSONObject("tentativeCommission");
						csSaleFlipkart.setAdId(jsonobject.getString("productId"));
						csSaleFlipkart.setSaleDt(jsonobject.getString("orderDate"));
						csSaleFlipkart.setCampaignId(null);
						csSaleFlipkart.setCouponId(jsonobject.getString("productId"));
						csSaleFlipkart.setId(jsonobject.getString("affiliateOrderItemId"));
						csSaleFlipkart.setNetwork("flipkart");
						csSaleFlipkart.setPayoutStatus(jsonobject.getString("status"));
						csSaleFlipkart.setSaleAmount(jobj.getString("amount"));
						csSaleFlipkart.setSaleComm(jobjComm.getString("amount"));
						if(jsonobject.getString("affExtParam1")!=null && !jsonobject.getString("affExtParam1").equals(""))
						{
							csSaleFlipkart.setUserId(Integer.parseInt(jsonobject.getString("affExtParam1")));
						}
						csSaleFlipkart.setRowEffDt(getCurrentDateOnly());
						
						//System.out.println("#feedtable-"+feedtable.toString());
					}catch(Exception e)
					{
						e.printStackTrace();
					}
					return csSaleFlipkart;
				}
		
				//For DealOfTheDay For Flipkart From Rest service
				public CsDotdFlipkart mapResponseToDealOfTheDayForFlipkart(JSONObject jsonobject)
				{
					String imageLogoUrl = "";
					String imageThumbUrl = "";
					CsDotdFlipkart csDotdFlipkart = new CsDotdFlipkart();
					try
					{
						JSONArray jArray = new JSONArray(jsonobject.getString("imageUrls"));
						JSONObject jObj = null;
						if(jArray!=null)
						{
							for(int i=0;i<jArray.length();i++)
							{
								jObj = jArray.getJSONObject(i);
								if(jObj.getString("resolutionType").equalsIgnoreCase("default"))
								{
									imageLogoUrl = jObj.getString("url");
								}
								else if(jObj.getString("resolutionType").equalsIgnoreCase("low"))
								{
									imageThumbUrl = jObj.getString("url");
								}
							}
						}
						csDotdFlipkart.setTitle(jsonobject.getString("title"));
						csDotdFlipkart.setDescription(jsonobject.getString("description"));
						csDotdFlipkart.setUrl(jsonobject.getString("url"));
						csDotdFlipkart.setImageurlLogo(imageLogoUrl);
						csDotdFlipkart.setImageurlThumbnail(imageThumbUrl);
						csDotdFlipkart.setRowEffDt(getCurrentDate().toString());
						csDotdFlipkart.setRowTermDt(null);
						csDotdFlipkart.setAvailability(jsonobject.getString("availability"));
						
						
						//System.out.println("#feedtable-"+feedtable.toString());
					}catch(Exception e)
					{
						e.printStackTrace();
					}
					return csDotdFlipkart;
				}
	
	
	//For FeedTable From Rest service
	public CsFeedtableDgm mapResponseToFeed(JSONObject jsonobject)
	{
		CsFeedtableDgm csFeedtableDgm = new CsFeedtableDgm();
		try
		{
			csFeedtableDgm.setLastVerified(jsonobject.getString("LastVerified"));
			csFeedtableDgm.setDealType(jsonobject.getString("DealType"));
			csFeedtableDgm.setDealCode(jsonobject.getString("DealCode"));
			csFeedtableDgm.setStoreName(jsonobject.getString("StoreName"));
			csFeedtableDgm.setDealLink(jsonobject.getString("DealLink"));
			csFeedtableDgm.setExclusive(jsonobject.getString("Exclusive"));
			csFeedtableDgm.setCampaignLogo(jsonobject.getString("CampaignLogo"));
			csFeedtableDgm.setExpired(jsonobject.getString("Expired"));
			csFeedtableDgm.setThumbnail(jsonobject.getString("Thumbnail"));
			csFeedtableDgm.setDealDescription(jsonobject.getString("DealDescription"));
			csFeedtableDgm.setDealTitle(jsonobject.getString("DealTitle"));
			csFeedtableDgm.setCouponCategoryId(jsonobject.getString("CouponCategoryId"));
			csFeedtableDgm.setCouponCategory(jsonobject.getString("CouponCategory"));
			csFeedtableDgm.setStoreId(jsonobject.getString("StoreId"));
			csFeedtableDgm.setId(jsonobject.getString("Id"));
			csFeedtableDgm.setRowEffDt(getCurrentDateOnly());
			//System.out.println("#feedtable-"+feedtable.toString());
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return csFeedtableDgm;
	}
	
		public CsFeedtableVcm mapResponseToFeedForCommon(JSONObject jsobObj) {
		// TODO Auto-generated method stub
			CsFeedtableVcm vcmFeedTable = new CsFeedtableVcm();
		try
		{
			vcmFeedTable.setCouponId(jsobObj.getString("promo_id"));
			vcmFeedTable.setCouponTitle(jsobObj.getString("coupon_title"));
			vcmFeedTable.setCouponDescription(jsobObj.getString("coupon_description"));
			vcmFeedTable.setCouponType(jsobObj.getString("coupon_type"));
			vcmFeedTable.setCouponCode(jsobObj.getString("coupon_code"));
			vcmFeedTable.setCouponLink(jsobObj.getString("link"));
			//vcmFeedTable.setAddedDate(getStringToDateForCommon(jsobObj.getString("added")));
			//vcmFeedTable.setExpiryDate(getStringToDateForCommon(jsobObj.getString("coupon_expiry")));
			vcmFeedTable.setCampaignId(Integer.parseInt(jsobObj.getString("offer_id")));
			vcmFeedTable.setCampaignName(jsobObj.getString("offer_name"));
			vcmFeedTable.setCategoryName(jsobObj.getString("category"));
			vcmFeedTable.setCampaignImage(jsobObj.getString("store_image"));
			//System.out.println("getCurrentDateOnly()--"+getCurrentDateOnly());
			vcmFeedTable.setRowEffDt(getCurrentDateOnly());
			vcmFeedTable.setRowTermDt(null);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return vcmFeedTable;
	}
	
	public ArrayList<CsCampaignDetailsVcm> mapResponseToCampaignDetailsForVCom(HashMap<String, JSONObject> objMap) {
		// TODO Auto-generated method stub
		//ArrayList<VcmCategory> vcmCategoryList = new ArrayList<VcmCategory>();
		ArrayList<CsCampaignDetailsVcm> vcmCampaignDetailsList = new ArrayList<CsCampaignDetailsVcm>();  
		CsCampaignDetailsVcm vcmCampaign = null;
		try
		{
			for(String key : objMap.keySet())
			{
				vcmCampaign = new CsCampaignDetailsVcm();
				JSONObject jobj = objMap.get(key).getJSONObject("Offer");
				vcmCampaign.setCampaignId(Integer.parseInt(jobj.getString("id")));
				vcmCampaign.setBrandName(jobj.getString("name"));
				vcmCampaign.setCampaignName(null);
				//System.out.println("------------------"+jobj.getString("description").trim());
				if(jobj.getString("description")!=null && jobj.getString("description").contains("<br>"))
				{
					String lines[] = jobj.getString("description").trim().split("\\r?\\n");
					//System.out.println("-------lines[0]-----------"+lines[0].replace("<br>", ""));
					vcmCampaign.setDescription(lines[0].replace("<br>", ""));
				}
				vcmCampaign.setApprovalStatus(Integer.parseInt(jobj.getString("require_approval")));
				vcmCampaign.setPayoutType(jobj.getString("payout_type"));
				vcmCampaign.setDefaultPayout(jobj.getString("default_payout"));
				vcmCampaign.setPercentPayout(jobj.getString("percent_payout"));
				vcmCampaign.setCouponsenaCampaignId(null);
				vcmCampaign.setCouponsenaCaimpaignName(null);
				vcmCampaign.setRowEffDt(getCurrentDateOnly());
				vcmCampaign.setRowTermDt(null);
				vcmCampaignDetailsList.add(vcmCampaign);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return vcmCampaignDetailsList;
	}
	
	public CsCampaignDetailsVcm mapResponseToCategoryCampaignForVCom(HashMap<String, String> catMap) {
		// TODO Auto-generated method stub
		CsCampaignDetailsVcm vcmCampaignCategory = new CsCampaignDetailsVcm();
		try
		{
			for(String key : catMap.keySet())
			{
				 if (key.compareToIgnoreCase("Campaign_id")==0)
				{
					//System.out.println("Campaign_id - Key/Value "+key+"/"+Integer.parseInt(catMap.get(key)));
					vcmCampaignCategory.setCampaignId(Integer.parseInt(catMap.get(key)));
				}
			}
			vcmCampaignCategory.setRowEffDt(getCurrentDateOnly().toString());
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return vcmCampaignCategory;
	}
		
			public ArrayList<CsCategoryDetailsVcm> mapResponseToCategoryDetailsForVCom(HashMap<String, JSONObject> objMap) {
				// TODO Auto-generated method stub
				ArrayList<CsCategoryDetailsVcm> vcmCategoryDetailsList = new ArrayList<CsCategoryDetailsVcm>();  
				CsCategoryDetailsVcm vcmCategoryDetails = null;
				try
				{
					for(String key : objMap.keySet())
					{
						vcmCategoryDetails = new CsCategoryDetailsVcm();
						JSONObject jobj = objMap.get(key).getJSONObject("OfferCategory");
						vcmCategoryDetails.setCategoryName(jobj.getString("name"));
						vcmCategoryDetails.setCategoryId(Integer.parseInt(jobj.getString("id")));
						vcmCategoryDetails.setCouponsenaCategoryId(null);
						vcmCategoryDetails.setCouponsenaCategoryName(null);
						vcmCategoryDetails.setRowEffDt(getCurrentDateOnly());
						vcmCategoryDetails.setRowTermDt(null);
						vcmCategoryDetailsList.add(vcmCategoryDetails);
					}
				}catch(Exception e)
				{
					e.printStackTrace();
				}
				return vcmCategoryDetailsList;
			}
			
			/*public ArrayList<CsCampaignGoalsVcm> mapResponseToCamapignGoalsForVCom(HashMap<String, JSONObject> objMap) {
				// TODO Auto-generated method stub
				ArrayList<CsCampaignGoalsVcm> csCampaignGoalsVcmList = new ArrayList<CsCampaignGoalsVcm>();  
				CsCampaignGoalsVcm csCampaignGoalsVcm = null;
				try
				{
					for(String key : objMap.keySet())
					{
						csCampaignGoalsVcm = new CsCampaignGoalsVcm();
						JSONObject jobj = objMap.get(key).getJSONObject("Goal");
						csCampaignGoalsVcm.setName(jobj.getString("name"));
						csCampaignGoalsVcm.setId(Integer.parseInt(jobj.getString("id")));
						csCampaignGoalsVcm.setCampaignId(Integer.parseInt(jobj.getString("offer_id")));
						csCampaignGoalsVcm.setDescription(jobj.getString("description"));
						csCampaignGoalsVcm.setPayoutType(jobj.getString("payout_type"));
						csCampaignGoalsVcm.setPercentPayout(jobj.getString("percent_payout"));
						csCampaignGoalsVcm.setDefaultPayout(jobj.getString("default_payout"));
						csCampaignGoalsVcm.setRowEffDt(getCurrentDate());
						csCampaignGoalsVcm.setRowTermDt(null);
						csCampaignGoalsVcmList.add(csCampaignGoalsVcm);
					}
				}catch(Exception e)
				{
					e.printStackTrace();
				}
				return csCampaignGoalsVcmList;
			}*/
	
			
			
			
			public ArrayList<CsSaleVcm> mapResponseToSaleVCom(ArrayList<HashMap<String, String>> saleMapList) {
				// TODO Auto-generated method stub
				ArrayList<CsSaleVcm> vcmSailList = new ArrayList<CsSaleVcm>();  
				CsSaleVcm csSaleVcm = null;
				try
				{
					for(HashMap<String, String> petMap : saleMapList)
					{
						csSaleVcm = new CsSaleVcm();
						for(String key : petMap.keySet())
						{
							if(key.equalsIgnoreCase("Id") && key !=null && !key.equalsIgnoreCase(""))
							{
								if(petMap.get(key)!=null && !petMap.get(key).equalsIgnoreCase(""))
								{
									csSaleVcm.setId(Integer.parseInt(petMap.get(key)));
								}
							}else if(key.equalsIgnoreCase("Payout_Status") && key !=null && !key.equalsIgnoreCase(""))
							{
								if(petMap.get(key)!=null && !petMap.get(key).equalsIgnoreCase(""))
								{
									csSaleVcm.setPayoutStatus(petMap.get(key));
								}
							}else if(key.equalsIgnoreCase("ad_id") && key !=null && !key.equalsIgnoreCase(""))
							{
								if(petMap.get(key)!=null && !petMap.get(key).equalsIgnoreCase(""))
								{
									csSaleVcm.setAdId(petMap.get(key));
								}
							}else if(key.equalsIgnoreCase("sale_amount") && key !=null && !key.equalsIgnoreCase(""))
							{
								if(petMap.get(key)!=null && !petMap.get(key).equalsIgnoreCase(""))
								{
									csSaleVcm.setSaleAmount(petMap.get(key));
								}
							}else if(key.equalsIgnoreCase("User_ID") && key != null && !key.equalsIgnoreCase(""))
							{
								if(petMap.get(key)!=null && !petMap.get(key).equalsIgnoreCase(""))
								{
									csSaleVcm.setUserId(Integer.parseInt(petMap.get(key)));
								}
							}else if(key.equalsIgnoreCase("Coupon_ID") && key !=null && !key.equalsIgnoreCase(""))
							{
								if(petMap.get(key)!=null && !petMap.get(key).equalsIgnoreCase(""))
								{
									csSaleVcm.setCouponId(key);
								}
							}else if(key.equalsIgnoreCase("Campaign_ID") && key !=null && !key.equalsIgnoreCase(""))
							{
								if(petMap.get(key)!=null && !petMap.get(key).equalsIgnoreCase(""))
								{	
									csSaleVcm.setCampaignId(Integer.parseInt(petMap.get(key)));
								}
							}else if(key.equalsIgnoreCase("Sale_Comm") && key !=null && !key.equalsIgnoreCase(""))
							{
								if(petMap.get(key)!=null && !petMap.get(key).equalsIgnoreCase(""))
								{
									csSaleVcm.setSaleComm(petMap.get(key));
								}
							}else if(key.equalsIgnoreCase("Sale_dt") && key !=null && !key.equalsIgnoreCase(""))
							{
								if(petMap.get(key)!=null && !petMap.get(key).equalsIgnoreCase(""))
								{
									csSaleVcm.setSaleDt(getStringToDateForSale(petMap.get(key)));
								}
							}
						}
						csSaleVcm.setRowEffDt(getCurrentDate());
						vcmSailList.add(csSaleVcm);
					}
				}catch(Exception e)
				{
					e.printStackTrace();
				}
				return vcmSailList;
			}
			
			
			
			
			
	
	//Get Character data from element
		public static String getCharacterDataFromElement(Element e) {
		    Node child = e.getFirstChild();
		    if (child instanceof CharacterData) {
		      CharacterData cd = (CharacterData) child;
		      return cd.getData();
		    }
		    return "";
		  }
		
		//Create String from SoapMessage 
		public static String soapMessageToString(SOAPMessage message) 
	    {
	        String result = null;

	        if (message != null) 
	        {
	            ByteArrayOutputStream baos = null;
	            try 
	            {
	                baos = new ByteArrayOutputStream();
	                message.writeTo(baos); 
	                result = baos.toString();
	            } 
	            catch (Exception e) 
	            {
	            	e.printStackTrace();
	            } 
	            finally 
	            {
	                if (baos != null) 
	                {
	                    try 
	                    {
	                        baos.close();
	                    } 
	                    catch (IOException ioe) 
	                    {
	                    	ioe.printStackTrace();
	                    }
	                }
	            }
	        }
	        return result;
	    }
		   
		
		public static Date getStringToDate(String dateValue)
		{
			//SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
            
            //convert Java String to Date using parse method of SimpleDateFormat
            Date date = null;
			try {
				if(dateValue!=null)
				{
					date = sdf.parse(dateValue);
				}
				//System.out.println("Date is: " + date);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
           
            return date;
		}
		
		public static String getDateOnlyFromDate(String dateValue) throws ParseException
		{
			Date date = getStringToDate(dateValue);
			//System.out.println("Before Processing--"+date);
			String modifiedDate= new SimpleDateFormat("MM-dd-yyyy").format(date);
			return modifiedDate;
		}
		
		
		public static Date getStringToDateForSale(String dateValue)
		{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            
            //convert Java String to Date using parse method of SimpleDateFormat
            Date date = null;
			try {
				if(dateValue!=null)
				{
					date = sdf.parse(dateValue);
				}
				//System.out.println("Date is: " + date);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
           
            return date;
		}

		public static Date getStringToDateForCommon(String dateValue)
		{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            
            //convert Java String to Date using parse method of SimpleDateFormat
            Date date = null;
			try {
				if(dateValue!=null)
				{
					date = sdf.parse(dateValue);
				}
				//System.out.println("Date is: " + date);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            return date;
		}
		
		public HashMap<String, JSONObject> jsonToMap(JSONObject jObject) throws JSONException {
			
			HashMap<String, JSONObject> map = new HashMap<String, JSONObject>();
			try
			{
		        Iterator<?> keys = jObject.keys();
		
		     //   	System.out.println("keys- "+keys);
		        
		        while( keys.hasNext() )
		        {
		            String key = keys.next().toString();
		       //     System.out.println(key);
		      //      System.out.println(jObject.getJSONObject(key));
		            map.put(key, jObject.getJSONObject(key));
		        }
		
			     //   System.out.println("json : "+jObject);
			      //  System.out.println("map : "+map);
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			return map;
	    }
		
		public HashMap<String, String> jsonArrayToMap(JSONArray jSONArray) throws JSONException {
			HashMap<String, String> map = new HashMap<String, String>();
			JSONObject jsonObject = null;
			JSONObject jsonObjectCategories= null;
			try
			{
				for(int i = 0;i<jSONArray.length();i++)
				{
					jsonObject = (JSONObject) jSONArray.get(i);
					if(jsonObject.getJSONObject("categories")!=null)
					{
						try
						{
							jsonObjectCategories = jsonObject.getJSONObject("categories");
							parse(jsonObjectCategories, map);
							map.put("Campaign_id", jsonObject.getString("offer_id"));
						}catch(Exception e)
						{
							e.printStackTrace();
						}
					}
				}
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			return map;
	    }
		
		public ArrayList<HashMap<String, String>> jsonArrayToMapForSaleVcm(JSONArray jSONArray) throws JSONException {
			ArrayList<HashMap<String, String>> listOfMap = new ArrayList<HashMap<String, String>>();
			JSONObject jsonObject = null;
			JSONObject jsonObjectCategories= null;
			try
			{
				//System.out.println("Now I do--"+jSONArray);
				for(int i = 0;i<jSONArray.length();i++)
				{
					//HashMap<String, String> map = new HashMap<String, String>();
					jsonObject = (JSONObject) jSONArray.get(i);
					jsonObjectCategories = jsonObject.getJSONObject("Stat");
					parseJsonForVcmSale(jsonObjectCategories, listOfMap);
					//map.put("Id", jsonObject.getString("id"));
					//System.out.println("jsonArrayToMapForSaleVcm()---map--"+listOfMap);
				}
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			return listOfMap;
	    }
			
		
		public static ArrayList<HashMap<String, String>> parseJsonForVcmSale(JSONObject json , ArrayList<HashMap<String, String>> listOfMap) throws JSONException{
		    Iterator<String> keys = json.keys();
		    
		    HashMap<String,String> out = new HashMap<>();
		    while(keys.hasNext()){
		        String key = keys.next();
		        String val = null;
		        try{
		             JSONObject value = json.getJSONObject(key);
		             parseJsonForVcmSale(value,listOfMap);
		        }catch(Exception e){
		            val = json.getString(key);
		        }
		        if(val != null){
		        	if(key.equalsIgnoreCase("datetime"))
		        	{
		        		out.put("Sale_dt",val);
		        	}
		        	else if(key.equalsIgnoreCase("approved_payout"))
		        	{
		        		out.put("Sale_Comm",val);
		        	}
		        	else if(key.equalsIgnoreCase("conversion_status"))
		        	{
		        		out.put("Payout_Status",val);
		        	}
		        	else if(key.equalsIgnoreCase("offer_id"))
		        	{
		        		out.put("Campaign_ID",val);
		        	}
		        	else if(key.equalsIgnoreCase("affiliate_info1"))
		        	{
		        		out.put("User_ID",val);
		        	}
		        	else if(key.equalsIgnoreCase("affiliate_info2"))
		        	{
		        		out.put("Coupon_ID",val);
		        	}
		        	else if(key.equalsIgnoreCase("id"))
		        	{
		        		out.put("id",val);
		        	}
		        	else if(key.equalsIgnoreCase("sale_amount"))
		        	{
		        		out.put("sale_amount",val);
		        	}
		        	else if(key.equalsIgnoreCase("ad_id"))
		        	{
		        		out.put("ad_id",val);
		        	}
		        }
		    }
		    listOfMap.add(out);
		    return listOfMap;
		}
			public static HashMap<String,String> parse(JSONObject json , HashMap<String,String> out) throws JSONException{
			    Iterator<String> keys = json.keys();
			    while(keys.hasNext()){
			        String key = keys.next();
			        String val = null;
			        try{
			             JSONObject value = json.getJSONObject(key);
			             parse(value,out);
			        }catch(Exception e){
			            val = json.getString(key);
			        }

			        if(val != null){
			        	if(key.equalsIgnoreCase("id"))
			        	{
			        		out.put("Category_id",val);
			        	}
			        	else if(key.equalsIgnoreCase("name"))
			        	{
			        		out.put("Category_name",val);
			        	}
			        }
			    }
			    return out;
			}
		
		
		public static Date getCurrentDate() throws ParseException
		{
			DateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
			Date today = new Date();
			Date todayWithZeroTime = formatter.parse(formatter.format(today));
			//System.out.println("Returning Date todayWithZeroTime --"+todayWithZeroTime);
			return todayWithZeroTime;
		}
		
		public static String getCurrentDateOnly() throws ParseException
		{
			Date date = new Date();
			String modifiedDate= new SimpleDateFormat("yyyy-MM-dd").format(date);
			return modifiedDate;
		}
		
		public static String getYestdayDateOnly() throws ParseException
		{
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_MONTH, -1);
			calendar.getTime();
			//System.out.println("getYestdayDateOnly--"+calendar.getTime());
			Date date = new Date();
			String modifiedDate= new SimpleDateFormat("yyyy-MM-dd").format(calendar.getTime());
			//System.out.println("getYestdayDateOnly return date-"+modifiedDate);
			return modifiedDate;
		}
		
		public static String getTimeMillsToDate(String tmeMills) throws ParseException
		{
			String dateVal = "";
			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			long milliSeconds= Long.parseLong(tmeMills);
			//System.out.println(milliSeconds);

			Calendar calendar = Calendar.getInstance();
			calendar.setTimeInMillis(milliSeconds);
			//System.out.println(formatter.format(calendar.getTime())); 
			dateVal = formatter.format(calendar.getTime());
			return dateVal;
		}
		
		public static BigDecimal getdecimalFromString(String decimalValue)
		{
			DecimalFormatSymbols symbols = new DecimalFormatSymbols();
			symbols.setGroupingSeparator(',');
			symbols.setDecimalSeparator('.');
			String pattern = "#,##0.0#";
			DecimalFormat decimalFormat = new DecimalFormat(pattern, symbols);
			decimalFormat.setParseBigDecimal(true);
			// parse the string
			BigDecimal bigDecimal = null;
			try {
				bigDecimal = (BigDecimal) decimalFormat.parse(decimalValue);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println(bigDecimal);
			return bigDecimal;
		}
}
