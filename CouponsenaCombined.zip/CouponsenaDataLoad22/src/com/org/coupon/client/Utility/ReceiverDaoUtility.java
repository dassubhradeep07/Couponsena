package com.org.coupon.client.Utility;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.org.coupon.dto.CsCampaignDetailsDgm;
import com.org.coupon.dto.CsCampaignDetailsVcm;
import com.org.coupon.dto.CsCategoryDetailsVcm;
import com.org.coupon.dto.CsDotdFlipkart;
import com.org.coupon.dto.CsFeedtableDgm;
import com.org.coupon.dto.CsFeedtableFlipkart;
import com.org.coupon.dto.CsFeedtableVcm;
import com.org.coupon.dto.CsSaleDgm;
import com.org.coupon.dto.CsSaleFlipkart;
import com.org.coupon.dto.CsSaleVcm;

public class ReceiverDaoUtility {
	private static SessionFactory sessionFactory = null;
	private static ServiceRegistry serviceRegistry = null;
	private static Configuration configuration = null;


	static {
		try {
			configuration = new Configuration();
			configuration.configure("hibernate.cfg.xml");
			serviceRegistry = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
		    sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Session openSession() {
		Session session = null;
		try {
			session = sessionFactory.openSession();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return session;
	}
	
	public static void closeSession(Session session)
	{
		if(session!=null)
		{
			session.close();
		}
	}
	
	public static boolean callProcedure(String procedure)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		Query callStoredProcedure_MYSQL = session.createSQLQuery(procedure);
		try {
			transaction = session.getTransaction();
			transaction.begin();
			int value = callStoredProcedure_MYSQL.executeUpdate();
			System.out.println("Excuting Value--procedure--"+value+"--"+procedure);
	        transaction.commit();
	        flag= true;	
		//}
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}
	
	public static boolean persistFeedTableForFlipkart(ArrayList<CsFeedtableFlipkart> listOfFlipKartObj)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			//System.out.println("Sessoin opened");
			//As Id generated From CFouponsena Side. So No Truncae Load
			//boolean deleteFlag = deleteAllFromTable("CsFeedtableFlipkart");
			//boolean deleteFlag = true;
			//System.out.println("deleteFlag--"+deleteFlag);
			//if (deleteFlag) {
				transaction = session.getTransaction();
				transaction.begin();
				for(CsFeedtableFlipkart csFeedtableFlipkart : listOfFlipKartObj)
				{
					//System.out.println("FlipKart URls--"+csFeedtableFlipkart.getUrl());
					session.saveOrUpdate(csFeedtableFlipkart);
				}
		        transaction.commit();
		        flag= true;	
			//}
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}
	
	public static boolean persistSaleTableForFlipkart(ArrayList<CsSaleFlipkart> listOfFlipKartObj)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			//System.out.println("Sessoin opened");
			boolean deleteFlag = deleteAllFromTable("CsSaleFlipkart");
			//boolean deleteFlag = true;
			//System.out.println("deleteFlag--"+deleteFlag);
			if (deleteFlag) {
				transaction = session.getTransaction();
				transaction.begin();
				for(CsSaleFlipkart csSaleFlipkart : listOfFlipKartObj)
				{
					//System.out.println("FlipKart URls--"+csFeedtableFlipkart.getUrl());
					session.saveOrUpdate(csSaleFlipkart);
				}
		        transaction.commit();
		        flag= true;	
			}
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}
	
	public static boolean persistDealOfTheDayForFlipkart(ArrayList<CsDotdFlipkart> listOfFlipKartObj)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			//System.out.println("Sessoin opened");
			transaction = session.getTransaction();
			transaction.begin();
			for(CsDotdFlipkart csDotdFlipkart : listOfFlipKartObj)
			{
				session.saveOrUpdate(csDotdFlipkart);
			}
	        transaction.commit();
	        flag= true;
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}
	
	public static boolean persistFeedTable(ArrayList<CsFeedtableDgm> CsFeedtableDgmList)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			//System.out.println("Sessoin opened");
			transaction = session.getTransaction();
			transaction.begin();
			for(CsFeedtableDgm csFeedtableDgm : CsFeedtableDgmList)
			{
				session.saveOrUpdate(csFeedtableDgm);
			}
	        transaction.commit();
	        flag= true;
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}
	
	//public static boolean persistFeedTableForCommon(ArrayList<VcmFeed> vcmFeedList)
	public static boolean persistFeedTableForCommon(ArrayList<CsFeedtableVcm> vcmFeedList)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.getTransaction();
			transaction.begin();
			//for (VcmFeed vcmFeed : vcmFeedList)
			for (CsFeedtableVcm vcmFeed : vcmFeedList)
			{
				session.saveOrUpdate(vcmFeed);
		        flag= true;
			}
			if(!transaction.wasCommitted())
			{
				transaction.commit();
			}
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}
	
	public static boolean persistCampaignTable(ArrayList<CsCampaignDetailsDgm> campaignList)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.getTransaction();
			transaction.begin();
			for(CsCampaignDetailsDgm campaign :campaignList)
			{
				//session.saveOrUpdate(campaign);
				session.merge(campaign);
			}
			if(!transaction.wasCommitted())
			{
				transaction.commit();
			}
	        flag= true;
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}
	
	
	public static boolean persistSalesTable(ArrayList<CsSaleDgm> saleList)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.getTransaction();
			transaction.begin();
			for(CsSaleDgm sale :saleList)
			{
				session.saveOrUpdate(sale);
				
			}
			if(!transaction.wasCommitted())
			{
				transaction.commit();
			}
	        flag= true;
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}
	
	
	/*public static boolean persistAdvertiseTable(ArrayList<Advertiserstats> advertiseList)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.getTransaction();
			transaction.begin();
			for(Advertiserstats advertise :advertiseList)
			{
				session.saveOrUpdate(advertise);
			}
	        transaction.commit();
	        flag= true;
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}*/
	
	public static boolean persistCategoryForVCom(ArrayList<CsCampaignDetailsVcm> vcmCampaignList)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.getTransaction();
			transaction.begin();
			for(CsCampaignDetailsVcm vcmCampaign : vcmCampaignList)
			{
				session.saveOrUpdate(vcmCampaign);
			}
	        transaction.commit();
	        flag= true;
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}
	
	public static boolean persistSaleForVCom(ArrayList<CsSaleVcm> vcmSaleList)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.getTransaction();
			transaction.begin();
			for(CsSaleVcm CsSaleVcm : vcmSaleList)
			{
				session.saveOrUpdate(CsSaleVcm);
			}
	        transaction.commit();
	        flag= true;
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}
	
	/*public static boolean persistCampaignCategoryForVCom(CsCampaignCategoryVcm vcmCampaignCategory)
	{
		boolean flag= false;
		Session session =null;
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
				transaction = session.getTransaction();
				transaction.begin();
					session.saveOrUpdate(vcmCampaignCategory);
		        transaction.commit();
		        flag= true;
		}catch (Exception e) {
			// TODO: handle exception
			flag=false;
			e.printStackTrace();
		}finally {
			closeSession(session);
		}
		return flag;
	}*/
	
		public static boolean persistCategoryDetailsForVCom(ArrayList<CsCategoryDetailsVcm> vcmCategoryDetailsList)
		{
			boolean flag= false;
			Session session =null;
			session = sessionFactory.openSession();
			Transaction transaction = null;
			try {
				transaction = session.getTransaction();
				transaction.begin();
				for(CsCategoryDetailsVcm vcmCategoryDetails : vcmCategoryDetailsList)
				{
					session.saveOrUpdate(vcmCategoryDetails);
				}
		        transaction.commit();
		        flag= true;
			}catch (Exception e) {
				// TODO: handle exception
				flag=false;
				e.printStackTrace();
			}finally {
				closeSession(session);
			}
			return flag;
		}
		
		/*public static boolean persistCamapignGoalsForVCom(ArrayList<CsCampaignGoalsVcm> csCampaignGoalsVcmList)
		{
			boolean flag= false;
			Session session =null;
			session = sessionFactory.openSession();
			Transaction transaction = null;
			try {
				transaction = session.getTransaction();
				transaction.begin();
				for(CsCampaignGoalsVcm csCampaignGoalsVcm : csCampaignGoalsVcmList)
				{
					session.saveOrUpdate(csCampaignGoalsVcm);
				}
		        transaction.commit();
		        flag= true;
			}catch (Exception e) {
				// TODO: handle exception
				flag=false;
				e.printStackTrace();
			}finally {
				closeSession(session);
			}
			return flag;
		}*/
		
		
		public static boolean deleteAllFromTable(String entityName)
		{
			boolean flag= false;
			Session session =null;
			session = sessionFactory.openSession();
			Transaction transaction = null;
			try {
				transaction = session.getTransaction();
				transaction.begin();
				Query query = session.createQuery("DELETE FROM "+entityName);
				int value = query.executeUpdate();
		        transaction.commit();
		        System.out.println("### "+entityName+" - Value returned in delete - "+value);
		        	flag= true;
			}catch (Exception e) {
				// TODO: handle exception
				flag=false;
				e.printStackTrace();
			}finally {
				closeSession(session);
			}
			return flag;
		}
}
