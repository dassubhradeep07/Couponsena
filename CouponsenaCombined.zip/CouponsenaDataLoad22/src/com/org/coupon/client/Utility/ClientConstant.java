package com.org.coupon.client.Utility;

public interface ClientConstant {
	
	final static String DGM_FEED_URL = "http://kouponfeed.com/api/download/69685/ZUXU3OSOQDDEKEYA/json";
	final static String DGM_VAR_LAST_BUILD_DATE = "lastBuildDate";
	final static String DGM_VAR_ITEM = "item";
	
	final static String VCOM_FEED_URL = "https://tools.vcommission.com/api/coupons.php?apikey=8eb842ead86b4820aac4f422e4e25f8897f68c71717845320a99468187765ed3";
	final static String VCOM_CAT_URL = "https://api.hasoffers.com/Apiv3/json?NetworkId=vcm&Target=Affiliate_Application&Method=findAllOfferCategories&api_key=8eb842ead86b4820aac4f422e4e25f8897f68c71717845320a99468187765ed3";
	final static String VCOM_CAM_DETAILS_URL = "https://api.hasoffers.com/Apiv3/json?NetworkId=vcm&Target=Affiliate_Offer&Method=findAll&api_key=8eb842ead86b4820aac4f422e4e25f8897f68c71717845320a99468187765ed3";
	final static String VCOM_CAM_CAT_URL = "https://api.hasoffers.com/Apiv3/json?NetworkId=vcm&Target=Affiliate_Offer&Method=getCategories&api_key=8eb842ead86b4820aac4f422e4e25f8897f68c71717845320a99468187765ed3&ids%5B%5D=";
	final static String VCOM_CAT_GOAL_URL = "https://api.hasoffers.com/Apiv3/json?NetworkId=vcm&Target=Affiliate_Goal&Method=findAll&api_key=8eb842ead86b4820aac4f422e4e25f8897f68c71717845320a99468187765ed3";
	final static String FLIPKART_FEED_URL = "https://affiliate-api.flipkart.net/affiliate/offers/v1/all/json";
	final static String FLIPKART_DOTD_URL = "https://affiliate-api.flipkart.net/affiliate/offers/v1/dotd/json";
	final static String VCOM_VAR_DATA = "data";
	final static String VCOM_VAR_RESPONSE = "response";

}
