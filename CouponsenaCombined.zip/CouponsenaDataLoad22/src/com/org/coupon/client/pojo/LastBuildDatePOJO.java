package com.org.coupon.client.pojo;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class LastBuildDatePOJO {
	private String lastBuildDate;
	
	public String getLastBuildDate() {
		return lastBuildDate;
	}
	public void setLastBuildDate(String lastBuildDate) {
		this.lastBuildDate = lastBuildDate;
	}
	@Override
	public String toString() {
		return "FeedTablePOJO [lastBuildDate=" + lastBuildDate + "]";
	}

}
