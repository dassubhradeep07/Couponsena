package com.org.coupon.client.pojo;

//@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemPOJOList {
	private String id;
	private String dealTitle;
	private String dealType;
	private String dealCode;
	private String dealDescription;
	private String dealLink;
	private String couponCategory;
	private Integer couponCategoryId;
	private String storeName;
	private Integer storeId;
	private String campaignLogo;
	private String LastVerified;
	private String expired;
	private String exclusive;
	private String thumbnail;

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	
	public String getDealTitle() {
		return this.dealTitle;
	}

	public void setDealTitle(String dealTitle) {
		this.dealTitle = dealTitle;
	}

	
	public String getDealType() {
		return this.dealType;
	}

	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	
	public String getDealCode() {
		return this.dealCode;
	}

	public void setDealCode(String dealCode) {
		this.dealCode = dealCode;
	}

	
	public String getDealDescription() {
		return this.dealDescription;
	}

	public void setDealDescription(String dealDescription) {
		this.dealDescription = dealDescription;
	}

	
	public String getDealLink() {
		return this.dealLink;
	}

	public void setDealLink(String dealLink) {
		this.dealLink = dealLink;
	}

	
	public String getCouponCategory() {
		return this.couponCategory;
	}

	public void setCouponCategory(String couponCategory) {
		this.couponCategory = couponCategory;
	}

	
	public Integer getCouponCategoryId() {
		return this.couponCategoryId;
	}

	public void setCouponCategoryId(Integer couponCategoryId) {
		this.couponCategoryId = couponCategoryId;
	}


	public String getStoreName() {
		return this.storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	
	public Integer getStoreId() {
		return this.storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}


	public String getCampaignLogo() {
		return this.campaignLogo;
	}

	public void setCampaignLogo(String campaignLogo) {
		this.campaignLogo = campaignLogo;
	}

	
	public String getLastVerified() {
		return this.LastVerified;
	}

	public void setLastVerified(String LastVerified) {
		/*if(LastVerified!=null && !LastVerified.equals(""))
		{
			this.LastVerified = LastVerified;
			
		}else
		{
			this.LastVerified = "";
		}*/
		this.LastVerified =null;
	}

	
	public String getExpired() {
		return this.expired;
	}

	public void setExpired(String expired) {
		this.expired = expired;
	}

	
	public String getExclusive() {
		return this.exclusive;
	}

	public void setExclusive(String exclusive) {
		this.exclusive = exclusive;
	}

	public String getThumbnail() {
		return this.thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	@Override
	public String toString() {
		return "FeedTablePOJOList [id=" + id + ", dealTitle=" + dealTitle + ", dealType=" + dealType + ", dealCode="
				+ dealCode + ", dealDescription=" + dealDescription + ", dealLink=" + dealLink + ", couponCategory="
				+ couponCategory + ", couponCategoryId=" + couponCategoryId + ", storeName=" + storeName + ", storeId="
				+ storeId + ", campaignLogo=" + campaignLogo + ", lastVerified=" + LastVerified + ", expired=" + expired
				+ ", exclusive=" + exclusive + ", thumbnail=" + thumbnail + "]";
	}
	
	
}
