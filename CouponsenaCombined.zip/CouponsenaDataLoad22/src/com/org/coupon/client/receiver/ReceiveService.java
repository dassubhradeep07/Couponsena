package com.org.coupon.client.receiver;

public class ReceiveService {
	
	PopulateFeedTable populateFeedTable;
	PopulateCampaignAndCategory populateCampaignAndCategory;
	PopulateSale populateSale; 
	PopulateDealOfTheDay populateDealOfTheDay;
	ExcuteProcedures excuteProcedures;
	
	public ReceiveService() {
		// TODO Auto-generated constructor stub
		System.out.println("Hibernate Version--"+org.hibernate.Version.getVersionString());
		this.populateFeedTable = new PopulateFeedTable();
		this.populateCampaignAndCategory = new PopulateCampaignAndCategory();
		this.populateSale = new PopulateSale();
		this.populateDealOfTheDay = new PopulateDealOfTheDay();
		this.excuteProcedures = new ExcuteProcedures();
	}
	
	public static void main(String[] args) {
		ReceiveService receiveService = new ReceiveService();
		receiveService.runServices();
	}

	public void runServices() {
		System.out.println("######################################## Process Started Successfully ########################################");
		System.out.println();
		Long START_TIME = System.currentTimeMillis();
		boolean flag = false;
		
		
		System.out.println("******************** All Feed Table Start ********************");
		flag = populateFeedTable.populateFeedTable();
		System.out.println("******************** All Feed Table End ********************");
		//System.out.println("### restPopulateFeedTable()-"+flag);
		
		if (flag)
			System.out.println("******************** All CampaignAndCategory Table Start ********************");
			flag = populateCampaignAndCategory.poplutaeCampaignAndCategoryTable();
			//System.out.println("### poplutaeCampaignTable()-"+flag);
			System.out.println();
			System.out.println("******************** All CampaignAndCategory Table End ********************");
		
		if(flag)
			System.out.println();
			System.out.println("******************** All Sales Table Start ********************");
			flag = populateSale.populateOverallSale();
			//System.out.println("### poplutaeSalesTable()-"+flag);
			System.out.println();
			System.out.println("******************** All Sales Table End ********************");
		
		if(flag)
			System.out.println("******************** DealOfTheDay Table Start ********************");
			flag = populateDealOfTheDay.PopulateDealOfTheDayTable();
			//System.out.println("### DealOfTheDay()-"+flag);
			System.out.println();
			System.out.println("******************** DealOfTheDay Table End ********************");
			
			if(flag)
				System.out.println("******************** Executing of Procedures Start ********************");
				flag = excuteProcedures.executeProcess();
				//System.out.println("### executeProcess()-"+flag);
				System.out.println();
				System.out.println("******************** Executing of Procedures End ********************");
		
		Long END_TIME = System.currentTimeMillis();
		if(flag)
		{
			System.out.println();
			Long TIME_TAKEN =(END_TIME-START_TIME);
			System.out.println(">>>>>>>>>>> Total Time Taken -- "+TIME_TAKEN/1000+" Sec.");
			System.out.println("######################################## Process Completed Successfully ########################################");
		}else
		{
			System.out.println();
			Long TIME_TAKEN =(END_TIME-START_TIME);
			System.out.println(">>>>>>>>>>> Total Time Taken -- "+TIME_TAKEN/1000+" Sec.");
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!! Process Completed With Error !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		}
	}
}
