package com.org.coupon.client.receiver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

public class Curl {
	public static void main(String[] args) {

		try {

			URL url = new URL("https://affiliate-api.flipkart.net/affiliate/offers/v1/all/json");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Fk-Affiliate-Token", "703377598dd049b8847815d497810ef2");
			conn.setRequestProperty("Fk-Affiliate-Id", "couponsen");
			Map<String, List<String>> returnMap = conn.getHeaderFields();
			System.out.println("returnMap-"+returnMap);

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
			}

			conn.disconnect();

		  } catch (MalformedURLException e) {

			e.printStackTrace();

		  } catch (IOException e) {

			e.printStackTrace();

		  }

	  }
}
