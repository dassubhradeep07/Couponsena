package com.org.coupon.client.receiver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.org.coupon.client.Utility.ClientConstant;
import com.org.coupon.client.Utility.ClientUtility;
import com.org.coupon.client.Utility.ReceiverDaoUtility;
import com.org.coupon.dto.CsFeedtableDgm;
import com.org.coupon.dto.CsFeedtableFlipkart;
import com.org.coupon.dto.CsFeedtableVcm;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class PopulateFeedTable {
	
	public boolean populateFeedTable()
	{
		boolean flag = false;
		
		flag = restPopulateFeedTableForDGM(ClientConstant.DGM_FEED_URL);
		flag = restPopulateFeedTableForVCom(ClientConstant.VCOM_FEED_URL);
		flag = restPopulateFeedTableForFlipkart(ClientConstant.FLIPKART_FEED_URL);
		
		return flag;
	}

	
	/************************************************Flipkart Feed Table Population**************************************************************/
	public boolean restPopulateFeedTableForFlipkart(String serviceURLFlipkart)
	{
		JSONObject jsonobjectzzz = null;
		JSONArray jsonarray = null;
		JSONObject jObj = null;
		int count = 0;
		CsFeedtableFlipkart csFeedtableFlipkart = null;
		ArrayList<CsFeedtableFlipkart> listOfFlipKartObj = new ArrayList<CsFeedtableFlipkart>();
		boolean flag = false;
		try {
			URL url = new URL(serviceURLFlipkart);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Fk-Affiliate-Token", "703377598dd049b8847815d497810ef2");
			conn.setRequestProperty("Fk-Affiliate-Id", "couponsen");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
			}

					
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output="";
			
			//System.out.println("Output from Server .... \n");
			
			while ((output = br.readLine()) != null) {
				//System.out.println(output);
				jsonobjectzzz =  new JSONObject(output);
			}
			conn.disconnect();

			jsonarray = jsonobjectzzz.getJSONArray("allOffersList");
			//System.out.println("jsonarray.length()--"+jsonarray.length());
			
			for(int i= 0 ;i < jsonarray.length();i++)
			{
				count++;
				jObj = jsonarray.getJSONObject(i);
				//System.out.println("jObj--"+jObj);
				csFeedtableFlipkart = ClientUtility.getInstance().mapResponseToFeedForFlipkart(jObj);
				listOfFlipKartObj.add(csFeedtableFlipkart);
			}
			
			if(listOfFlipKartObj!=null && listOfFlipKartObj.size()>0)
			{
				flag = ReceiverDaoUtility.persistFeedTableForFlipkart(listOfFlipKartObj);
				System.out.println("### Total Count persistFeedTableForFlipkart--"+count);
			}

		  } catch (MalformedURLException e) {

			e.printStackTrace();

		  } catch (IOException e) {

			e.printStackTrace();

		  } catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	
	/************************************************DGM Feed Table Population**************************************************************/
	public boolean restPopulateFeedTableForDGM(String serviceURLDGM)
	{
		JSONObject jsonobjectzzz;
		//Feedtable feedTable = null;
		CsFeedtableDgm csFeedtableDgm = null; 
		ArrayList<CsFeedtableDgm> feedTableList = new ArrayList<CsFeedtableDgm>();
		boolean flag = false;
		try
		{
			Client client = Client.create();
			WebResource webResource = client.resource(serviceURLDGM);
			ClientResponse response = webResource.accept("application/json").get(ClientResponse.class);
	
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
			}
	
			String output = response.getEntity(String.class);
			JSONArray jsonarray = new JSONArray(output);
			
			//	System.out.println("jsonarray.length()--"+jsonarray.length());
			
			for (int i = 0; i < jsonarray.length(); i++) {
				JSONObject jsonobject = jsonarray.getJSONObject(i);
				if(i==0)
				{
					String lastBuildDatePOJO=jsonobject.getString(ClientConstant.DGM_VAR_LAST_BUILD_DATE);
					System.out.println("### lastBuildDate - "+lastBuildDatePOJO);
				}else
				{
					JSONArray jsonarrayItem =jsonobject.getJSONArray(ClientConstant.DGM_VAR_ITEM);
					
				//	System.out.println("#######################"+Arrays.asList(jsonarrayItem));
				//	System.out.println("jsonarrayItem.length()--"+jsonarrayItem.length());
					
					int count = 0;
					for(int j=0;j<jsonarrayItem.length();j++)
					{
						count++;
						jsonobjectzzz=(JSONObject) jsonarrayItem.get(j);
						//feedTable = ClientUtility.getInstance().mapResponseToFeed(jsonobjectzzz);
						csFeedtableDgm = ClientUtility.getInstance().mapResponseToFeed(jsonobjectzzz);
						feedTableList.add(csFeedtableDgm);
					}
					if(feedTableList.size()>0)
					{
						flag = ReceiverDaoUtility.persistFeedTable(feedTableList);
					}
					System.out.println("### Total Count restPopulateFeedTableForDGM -- "+count);
				}
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	/************************************************VComission Feed Table Population**************************************************************/
	public boolean restPopulateFeedTableForVCom(String serviceURLVCom)
	{
		boolean flag = false;
		int count = 0;
		//ArrayList<VcmFeed> vcmFeedList = new ArrayList<VcmFeed>();
		ArrayList<CsFeedtableVcm> vcmFeedList = new ArrayList<CsFeedtableVcm>();
		try
		{
			Client client = Client.create();
			WebResource webResource = client.resource(serviceURLVCom);
			ClientResponse response = webResource.accept("application/json").get(ClientResponse.class);
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
			}
	
			String output = response.getEntity(String.class);
			JSONArray jsonarray = new JSONArray(output);
		//	System.out.println("output--"+output);
			JSONObject jsonobject = null;
			for (int i = 0; i < jsonarray.length(); i++)
			{
			   count++;
			   jsonobject = jsonarray.getJSONObject(i);
			   //VcmFeed vcmFeed = ClientUtility.getInstance().mapResponseToFeedForCommon(jsonobject);
			   CsFeedtableVcm vcmFeed = ClientUtility.getInstance().mapResponseToFeedForCommon(jsonobject);
			   vcmFeedList.add(vcmFeed);
			}
			if(vcmFeedList.size()>0)
			{
				flag = ReceiverDaoUtility.persistFeedTableForCommon(vcmFeedList);
			}
			System.out.println("### Total Count restPopulateFeedTableForVCom -- "+count);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
}
