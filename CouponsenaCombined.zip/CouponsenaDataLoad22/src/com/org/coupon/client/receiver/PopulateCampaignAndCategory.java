package com.org.coupon.client.receiver;

import java.io.IOException;
import java.io.StringReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.codehaus.jettison.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.org.coupon.client.Utility.ClientConstant;
import com.org.coupon.client.Utility.ClientUtility;
import com.org.coupon.client.Utility.ReceiverDaoUtility;
import com.org.coupon.dto.CsCampaignDetailsDgm;
import com.org.coupon.dto.CsCampaignDetailsVcm;
import com.org.coupon.dto.CsCategoryDetailsVcm;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;


public class PopulateCampaignAndCategory {

	ArrayList<CsCampaignDetailsVcm> vcmCampaignDetailsListForCampaignCategory = null;
	public boolean poplutaeCampaignAndCategoryTable()
	{
		boolean flag = false;
		flag = poplutaeCampaignDetailsTableForVComission(ClientConstant.VCOM_CAM_DETAILS_URL);
		flag = poplutaeCategoryDetailsTableForVComission(ClientConstant.VCOM_CAT_URL);
		//flag = poplutaeCampaignCategoryTableForVComission(ClientConstant.VCOM_CAM_CAT_URL);
		//flag = poplutaeCampaignGoalsTableForVComission(ClientConstant.VCOM_CAT_GOAL_URL);
		flag = poplutaeCampaignTableForDGM();
		return flag;
	}
	
	
	/************************************************VComission Campaign Table Population********************************************************/
	public boolean poplutaeCampaignDetailsTableForVComission(String serviceURL)
	{
		boolean flag = false;
		JSONObject jsonObj = null;
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(serviceURL);
			ClientResponse response = webResource.accept("application/json").get(ClientResponse.class);
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
			}
	
			String output = response.getEntity(String.class);
			jsonObj = new JSONObject(output);
			jsonObj = jsonObj.getJSONObject(ClientConstant.VCOM_VAR_RESPONSE).getJSONObject(ClientConstant.VCOM_VAR_DATA);
			HashMap<String, JSONObject> objMap= ClientUtility.getInstance().jsonToMap(jsonObj);
			//ArrayList<VcmCategory> vcmCategoryList = ClientUtility.getInstance().mapResponseToCategoryForVCom(objMap);
			ArrayList<CsCampaignDetailsVcm> vcmCampaignDetailsList = ClientUtility.getInstance().mapResponseToCampaignDetailsForVCom(objMap);
			vcmCampaignDetailsListForCampaignCategory = vcmCampaignDetailsList;
			flag = ReceiverDaoUtility.persistCategoryForVCom(vcmCampaignDetailsList);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public boolean poplutaeCategoryDetailsTableForVComission(String serviceURL)
	{
		boolean flag = false;
		JSONObject jsonObj = null;
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(serviceURL);
			ClientResponse response = webResource.accept("application/json").get(ClientResponse.class);
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
			}
	
			String output = response.getEntity(String.class);
			//System.out.println("poplutaeCategoryTableForVComission--"+output);
			jsonObj = new JSONObject(output);
			jsonObj = jsonObj.getJSONObject(ClientConstant.VCOM_VAR_RESPONSE).getJSONObject(ClientConstant.VCOM_VAR_DATA);
			//System.out.println(""+jsonObj);
			HashMap<String, JSONObject> objMap= ClientUtility.getInstance().jsonToMap(jsonObj);
			//ArrayList<VcmCategory> vcmCategoryList = ClientUtility.getInstance().mapResponseToCategoryForVCom(objMap);
			ArrayList<CsCategoryDetailsVcm> vcmCategoryDetailsList = ClientUtility.getInstance().mapResponseToCategoryDetailsForVCom(objMap);
			flag = ReceiverDaoUtility.persistCategoryDetailsForVCom(vcmCategoryDetailsList);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	/*public boolean poplutaeCampaignCategoryTableForVComission(String serviceURL)
	{
		boolean flag = false;
		JSONObject jsonObj = null;
		WebResource webResource = null;
		ClientResponse response = null;
		String campaignId = "";
		try {
			Client client = Client.create();
			int count = 0;
			System.out.println("vcmCampaignDetailsListForCampaignCategory size - "+vcmCampaignDetailsListForCampaignCategory.size());
			boolean deleteFlag = ReceiverDaoUtility.deleteAllFromTable("CsCampaignCategoryVcm");
			for(CsCampaignDetailsVcm csCampaignDetailsVcm: vcmCampaignDetailsListForCampaignCategory)
			{
				count++;
				//System.out.println("csCampaignDetailsVcm - "+csCampaignDetailsVcm.toString());
				campaignId = csCampaignDetailsVcm.getCampaignId()+"";
				webResource = client.resource(serviceURL+campaignId);
				//System.out.println("campaignId For---"+campaignId);
				response = webResource.accept("application/json").get(ClientResponse.class);
				if (response.getStatus() != 200) {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				String output = response.getEntity(String.class);
				jsonObj = new JSONObject(output);
				JSONArray jSONArray = jsonObj.getJSONObject(ClientConstant.VCOM_VAR_RESPONSE).getJSONArray(ClientConstant.VCOM_VAR_DATA);
				//System.out.println("JSONArray XXXXX----- "+ jSONArray);
				HashMap<String, String> catMap= ClientUtility.getInstance().jsonArrayToMap(jSONArray);
				//System.out.println("catMap---"+catMap);
				CsCampaignDetailsVcm vcmCampaignCategory = ClientUtility.getInstance().mapResponseToCategoryCampaignForVCom(catMap);
				if(deleteFlag)
				{
					flag = ReceiverDaoUtility.persistCampaignCategoryForVCom(vcmCampaignCategory);
				}
			}
			System.out.println("### csCampaignDetailsVcm Count - "+count);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}*/
	
	/*public boolean poplutaeCampaignGoalsTableForVComission(String serviceURL)
	{
		boolean flag = false;
		JSONObject jsonObj = null;
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(serviceURL);
			ClientResponse response = webResource.accept("application/json").get(ClientResponse.class);
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
			}
	
			String output = response.getEntity(String.class);
			//System.out.println("~~~~~~~poplutaeCampaignGoalsTableForVComission~~~~~~~"+output);
			jsonObj = new JSONObject(output);
			jsonObj = jsonObj.getJSONObject(ClientConstant.VCOM_VAR_RESPONSE).getJSONObject(ClientConstant.VCOM_VAR_DATA);
			//System.out.println("jsonObj--"+jsonObj);
			HashMap<String, JSONObject> objMap= ClientUtility.getInstance().jsonToMap(jsonObj);
			//ArrayList<VcmCategory> vcmCategoryList = ClientUtility.getInstance().mapResponseToCategoryForVCom(objMap);
			ArrayList<CsCampaignGoalsVcm> csCampaignGoalsVcmList = ClientUtility.getInstance().mapResponseToCamapignGoalsForVCom(objMap);
			flag = ReceiverDaoUtility.persistCamapignGoalsForVCom(csCampaignGoalsVcmList);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}*/
	
	/************************************************DGM Campaign Table Population**************************************************************/
	
	
	public boolean poplutaeCampaignTableForDGM()
	{
		boolean flag = false;
		try {
			// Create SOAP Connection
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory.createConnection();

			// Send SOAP Message to SOAP Server
			String url = "http://webservices.dgperform.com/dgmpublisherwebservices.cfc?wsdl";
			SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(), url);

			// Process the SOAP Response
			flag = processSOAPResponse(soapResponse);
			//System.out.println("End");
			soapConnection.close();
		} catch (Exception e) {
			flag=false;
			System.err.println("Error occurred while sending SOAP Request to Server");
			e.printStackTrace();
		}
		return flag;
	}
	
	//Process Soap Response
	private static boolean processSOAPResponse(SOAPMessage soapResponse) throws Exception {
		String xml ="";
		String finalMessage = "";
		boolean flag = false;
		xml = ClientUtility.soapMessageToString(soapResponse);
		//System.out.println("Error In XML--"+xml);
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = null;
		try {
		    db = dbf.newDocumentBuilder();
		    InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(xml));
		    try {
		        Document doc = db.parse(is);
		        finalMessage = doc.getDocumentElement().getTextContent().trim();
		       // System.out.println("finalMessage---"+finalMessage);
		        ArrayList<CsCampaignDetailsDgm> campaignList = (ArrayList<CsCampaignDetailsDgm>) parseXml(finalMessage);
		        flag = ReceiverDaoUtility.persistCampaignTable(campaignList);
		        //System.out.println("campaign.toString()---"+campaignList.size());
		    } catch (SAXException e) {
		    	flag = false;
		    	e.printStackTrace();
		        // handle SAXException
		    } catch (IOException e) {
		        // handle IOException
		    	flag = false;
		    	e.printStackTrace();
		    }
		} catch (ParserConfigurationException e1) {
		    // handle ParserConfigurationException
			flag = false;
			e1.printStackTrace();
		}
		return flag;
	    
	}
	
	//Parse Xml String
	private static List<CsCampaignDetailsDgm> parseXml(String message) throws ParserConfigurationException, SAXException, IOException, ParseException
	{
		NodeList node;
		Element line;
		ArrayList<CsCampaignDetailsDgm> campaignList = new ArrayList<CsCampaignDetailsDgm>();
		CsCampaignDetailsDgm campaign = null;
		DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	    InputSource is = new InputSource();
	    is.setCharacterStream(new StringReader(message));

	    Document doc = db.parse(is);
	    NodeList nodes = doc.getElementsByTagName("campaign");

	    for (int i = 0; i < nodes.getLength(); i++) {
	    	
	      campaign = new CsCampaignDetailsDgm();
	      Element element = (Element) nodes.item(i);

	      node = element.getElementsByTagName("campaignid");
	      line = (Element) node.item(0);
	      campaign.setCampaignid(Integer.parseInt(ClientUtility.getCharacterDataFromElement(line)));
	     // System.out.println("campaignid: " + ClientUtility.getCharacterDataFromElement(line));

	      node = element.getElementsByTagName("campaignname");
	      line = (Element) node.item(0);
	      campaign.setCampaignname(ClientUtility.getCharacterDataFromElement(line));
	     // System.out.println("campaignname: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("advertiserid");
	      line = (Element) node.item(0);
	      campaign.setAdvertiserid(Integer.parseInt(ClientUtility.getCharacterDataFromElement(line)));
	      //System.out.println("advertiserid: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("advertisername");
	      line = (Element) node.item(0);
	      campaign.setAdvertisername(ClientUtility.getCharacterDataFromElement(line));
	     // System.out.println("advertisername: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("subscribeddate");
	      line = (Element) node.item(0);
	     // System.out.println("subscribeddate-------"+ClientUtility.getDateOnlyFromDate(ClientUtility.getCharacterDataFromElement(line)));
	      campaign.setSubscribeddate(ClientUtility.getDateOnlyFromDate(ClientUtility.getCharacterDataFromElement(line)).toString());
	     // System.out.println("subscribeddate: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("approvaltype");
	      line = (Element) node.item(0);
	      campaign.setApprovaltype(ClientUtility.getCharacterDataFromElement(line));
	     // System.out.println("approvaltype: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      campaign.setRowEffDt(ClientUtility.getCurrentDateOnly());
	      
	      campaignList.add(campaign);
	    }
		return campaignList;
	}
	
	
	 
	//Create Soap Request 
	private static SOAPMessage createSOAPRequest() throws SOAPException, IOException {
		MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();

        String serverURI = "http://www.dgperform.com/";

        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("def", serverURI);

        // SOAP Body
        SOAPBody soapBody = envelope.getBody();
        SOAPElement soapBodyElem = soapBody.addChildElement("getCampaigns", "def");
        SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("username");
        soapBodyElem1.addTextNode("amitava.thakur");
        SOAPElement soapBodyElem2 = soapBodyElem.addChildElement("password");
        soapBodyElem2.getNodeType();
        soapBodyElem2.addTextNode("dexter1988");
        SOAPElement soapBodyElem3 = soapBodyElem.addChildElement("approvalType");
        soapBodyElem3.addTextNode("approved");

        MimeHeaders headers = soapMessage.getMimeHeaders();
        headers.addHeader("SOAPAction", serverURI  + "getCampaigns");

        soapMessage.saveChanges();

        // Print the request message
       // System.out.print("Request SOAP Message = ");
        soapMessage.writeTo(System.out);
       // System.out.println();
        return soapMessage;
	}
}
