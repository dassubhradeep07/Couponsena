package com.org.coupon.client.receiver;

import java.util.LinkedList;

import com.org.coupon.client.Utility.ReceiverDaoUtility;

public class ExcuteProcedures {
	static LinkedList<String> lisOfprocs = null;
	
	static
	{
		lisOfprocs = new LinkedList<String>();
		lisOfprocs.add("call sp_cs_category_master");
		lisOfprocs.add("call sp_update_category_affiliate");
		lisOfprocs.add("call sp_cs_campaign_master");
		lisOfprocs.add("call sp_cs_campaign_affiliate");
		lisOfprocs.add("call sp_cs_feedtable_master");
		lisOfprocs.add("call sp_cs_sale_master");
		lisOfprocs.add("call sp_cs_user_sale_details");
		lisOfprocs.add("call sp_cs_user_cashback");
	}
	
	public boolean executeProcess() {
		boolean flag = false;
		for(String proc : lisOfprocs)
		{
			System.out.println("### Calling Procedure--"+proc);
			flag = callStoreProcecdure(proc);
		}
		return flag;
	}
	
	public boolean callStoreProcecdure(String procdurename)
	{
		boolean flag = ReceiverDaoUtility.callProcedure(procdurename);
		return flag;
	}
	
}
