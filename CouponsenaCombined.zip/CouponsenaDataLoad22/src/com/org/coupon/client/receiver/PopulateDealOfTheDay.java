package com.org.coupon.client.receiver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.org.coupon.client.Utility.ClientConstant;
import com.org.coupon.client.Utility.ClientUtility;
import com.org.coupon.client.Utility.ReceiverDaoUtility;
import com.org.coupon.dto.CsDotdFlipkart;

public class PopulateDealOfTheDay {

	public boolean PopulateDealOfTheDayTable()
	{
		boolean flag = false;
		flag = PopulateDealOfTheDayForFlipkart(ClientConstant.FLIPKART_DOTD_URL);
		return flag;
	}
	
	public boolean PopulateDealOfTheDayForFlipkart(String Url)
	{
		boolean flag = false;
		JSONObject jsonobjectzzz = null;
		JSONArray jsonarray = null;
		JSONObject jObj = null;
		int count = 0;
		CsDotdFlipkart csDotdFlipkart = null;
		ArrayList<CsDotdFlipkart> csDotdFlipkartList = new ArrayList<CsDotdFlipkart>();
		try {
			URL url = new URL(Url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Fk-Affiliate-Token", "703377598dd049b8847815d497810ef2");
			conn.setRequestProperty("Fk-Affiliate-Id", "couponsen");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
			}

					
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output="";
			
			//System.out.println("Output from Server .... \n");
			
			while ((output = br.readLine()) != null) {
				//System.out.println(output);
				jsonobjectzzz =  new JSONObject(output);
			}
			conn.disconnect();

			jsonarray = jsonobjectzzz.getJSONArray("dotdList");
			//System.out.println("jsonarray.length()--"+jsonarray.length());
			
			for(int i= 0 ;i < jsonarray.length();i++)
			{
				count++;
				jObj = jsonarray.getJSONObject(i);
				System.out.println("dotdList - jObj--"+jObj);
				csDotdFlipkart = ClientUtility.getInstance().mapResponseToDealOfTheDayForFlipkart(jObj);
				csDotdFlipkartList.add(csDotdFlipkart);
			}
			System.out.println("count--"+count);
			
			if(csDotdFlipkartList!=null && csDotdFlipkartList.size()>0)
			{
				flag = ReceiverDaoUtility.persistDealOfTheDayForFlipkart(csDotdFlipkartList);
				System.out.println("### Total Count persistDealOfTheDayForFlipkart--"+count);
			}

		  } catch (MalformedURLException e) {

			e.printStackTrace();

		  } catch (IOException e) {

			e.printStackTrace();

		  } catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	}
}
