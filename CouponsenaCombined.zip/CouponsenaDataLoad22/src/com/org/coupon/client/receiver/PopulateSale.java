package com.org.coupon.client.receiver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.org.coupon.client.Utility.ClientConstant;
import com.org.coupon.client.Utility.ClientUtility;
import com.org.coupon.client.Utility.ReceiverDaoUtility;
import com.org.coupon.dto.CsSaleDgm;
import com.org.coupon.dto.CsSaleFlipkart;
import com.org.coupon.dto.CsSaleVcm;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class PopulateSale {
	
	public boolean populateOverallSale()
	{
		boolean flag = false;
		flag = poplutaeSalesTableDgm();
		flag = poplutaeSaleForVComission();
		flag = populateSaleForFlipkart();
		return flag;
	}
	
	/************************************************ Flipkart Sale Table Population**************************************************************/
	public boolean populateSaleForFlipkart()
	{
		String serviceURLFlipkart="https://affiliate-api.flipkart.net/affiliate/report/orders/detail/json?startDate=2015-10-01&endDate=2016-11-01&status=approved&offset=0";
		JSONObject jsonobjectzzz = null;
		JSONArray jsonarray = null;
		JSONObject jObj = null;
		int count = 0;
		CsSaleFlipkart csSaleFlipkart = null;
		ArrayList<CsSaleFlipkart> listOfCsSaleFlipkart = new ArrayList<CsSaleFlipkart>();
		boolean flag = false;
		try {
			URL url = new URL(serviceURLFlipkart);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Fk-Affiliate-Token", "703377598dd049b8847815d497810ef2");
			conn.setRequestProperty("Fk-Affiliate-Id", "couponsen");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
			}

					
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output="";
			
			//System.out.println("Output from Server .... \n");
			
			while ((output = br.readLine()) != null) {
				//System.out.println(output);
				jsonobjectzzz =  new JSONObject(output);
			}
			conn.disconnect();

			jsonarray = jsonobjectzzz.getJSONArray("orderList");
			System.out.println("jsonarray.length() FRom orderList--"+jsonarray.length());
			
			for(int i= 0 ;i < jsonarray.length();i++)
			{
				count++;
				jObj = jsonarray.getJSONObject(i);
				//System.out.println("jObj--"+jObj);
				csSaleFlipkart = ClientUtility.getInstance().mapResponseToSaleForFlipkart(jObj);
				listOfCsSaleFlipkart.add(csSaleFlipkart);
			}
			
			if(listOfCsSaleFlipkart!=null && listOfCsSaleFlipkart.size()>0)
			{
				flag = ReceiverDaoUtility.persistSaleTableForFlipkart(listOfCsSaleFlipkart);
				System.out.println("### Total Count populateSaleForFlipkart--"+count);
			}
		  } catch (MalformedURLException e) {

			e.printStackTrace();

		  } catch (IOException e) {

			e.printStackTrace();

		  } catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	/***********************************Section For VCM****************************************/
	public boolean poplutaeSaleForVComission()
	{
		String serviceURL = "https://api.hasoffers.com/Apiv3/json?NetworkId=vcm&Target=Affiliate_Report&Method=getConversions&api_key=8eb842ead86b4820aac4f422e4e25f8897f68c71717845320a99468187765ed3&fields%5B%5D=Stat.id&fields%5B%5D=Stat.ad_id&fields%5B%5D=Stat.affiliate_info1&fields%5B%5D=Stat.affiliate_info2&fields%5B%5D=Stat.approved_payout&fields%5B%5D=Stat.conversion_status&fields%5B%5D=Stat.datetime&fields%5B%5D=Stat.offer_id&fields%5B%5D=Stat.sale_amount";
		boolean flag = false;
		JSONObject jsonObj = null;
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(serviceURL);
			ClientResponse response = webResource.accept("application/json").get(ClientResponse.class);
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
			}
			System.out.println("poplutaeSaleForVComission()----------------------");
			String output = response.getEntity(String.class);
			jsonObj = new JSONObject(output);
			JSONArray jSONArray = jsonObj.getJSONObject(ClientConstant.VCOM_VAR_RESPONSE).getJSONObject(ClientConstant.VCOM_VAR_DATA).getJSONArray(ClientConstant.VCOM_VAR_DATA);
			ArrayList<HashMap<String, String>> saleMapList= ClientUtility.getInstance().jsonArrayToMapForSaleVcm(jSONArray);
			//System.out.println("saleMapList Dekho**-----"+saleMapList);
			ArrayList<CsSaleVcm> vcmSaleList = ClientUtility.getInstance().mapResponseToSaleVCom(saleMapList);
			flag = ReceiverDaoUtility.persistSaleForVCom(vcmSaleList);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	/***********************************Section For VCM****************************************/
	
	/***********************************Section For DGM****************************************/
	public boolean poplutaeSalesTableDgm()
	{
		boolean flag = false;
		try {
			// Create SOAP Connection
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory.createConnection();

			// Send SOAP Message to SOAP Server
			String url = "http://webservices.dgperform.com/dgmpublisherwebservices.cfc?wsdl";
			SOAPMessage soapResponse = soapConnection.call(createSOAPRequestForDgm(), url);

			// Process the SOAP Response
			flag = processSOAPResponseDgm(soapResponse);
			//System.out.println("End");
			soapConnection.close();
		} catch (Exception e) {
			flag=false;
			System.err.println("Error occurred while sending SOAP Request to Server");
			e.printStackTrace();
		}
		return flag;
	}
	
	//Process Soap Response
	private static boolean processSOAPResponseDgm(SOAPMessage soapResponse) throws Exception {
		String xml ="";
		String finalMessage = "";
		boolean flag = false;
		xml = ClientUtility.soapMessageToString(soapResponse);
		//System.out.println("Response XML After Change--"+xml);
		//PrintWriter out = new PrintWriter("E:\\Workz\\PROJECTS\\Coupon Site\\Dump20160901\\SaleDGMXML.txt");
		//out.println(xml);
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = null;
		try {
		    db = dbf.newDocumentBuilder();
		    InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(xml));
		    try {
		        Document doc = db.parse(is);
		        finalMessage = doc.getDocumentElement().getTextContent().trim();
		        //System.out.println("finalMessage---"+finalMessage);
		        ArrayList<CsSaleDgm> salesList = (ArrayList<CsSaleDgm>) parseXmlForDgm(finalMessage);
		        //System.out.println("salesList Size---"+salesList.size());
		        ReceiverDaoUtility.persistSalesTable(salesList);
		        flag = true;
		    } catch (SAXException e) {
		    	flag = false;
		    	e.printStackTrace();
		        // handle SAXException
		    } catch (IOException e) {
		        // handle IOException
		    	flag = false;
		    	e.printStackTrace();
		    }
		} catch (ParserConfigurationException e1) {
		    // handle ParserConfigurationException
			flag = false;
			e1.printStackTrace();
		}
		return flag;
	    
	}
	
	//Parse Xml String
	private static List<CsSaleDgm> parseXmlForDgm(String message) throws ParserConfigurationException, SAXException, IOException, ParseException
	{
		NodeList node;
		Element line;
		ArrayList<CsSaleDgm> saleList = new ArrayList<CsSaleDgm>();
		CsSaleDgm sale = null;
		ArrayList<String> salesIdList = new ArrayList<>();
		DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	    InputSource is = new InputSource();
	    is.setCharacterStream(new StringReader(message));

	    Document doc = db.parse(is);
	    NodeList nodes = doc.getElementsByTagName("sale");

	    for (int i = 0; i < nodes.getLength(); i++) {
	    	
	      sale = new CsSaleDgm();
	      Element element = (Element) nodes.item(i);
	      
	      node = element.getElementsByTagName("SaleID");
	      line = (Element) node.item(0);
	      sale.setSaleId(ClientUtility.getCharacterDataFromElement(line));
	      //System.out.println("SaleID: " + ClientUtility.getCharacterDataFromElement(line));
	     if(!salesIdList.contains(ClientUtility.getCharacterDataFromElement(line))){
	      salesIdList.add(ClientUtility.getCharacterDataFromElement(line));
	      node = element.getElementsByTagName("CampaignName");
	      line = (Element) node.item(0);
	      sale.setCampaignName(ClientUtility.getCharacterDataFromElement(line));
	      //System.out.println("CampaignName: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("CampaignID");
	      line = (Element) node.item(0);
	      sale.setCampaignId(ClientUtility.getCharacterDataFromElement(line));
	      //System.out.println("CampaignID: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("AdvertiserName");
	      line = (Element) node.item(0);
	      sale.setAdvertiserName(ClientUtility.getCharacterDataFromElement(line));
	      //System.out.println("AdvertiserName: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("CompanyID");
	      line = (Element) node.item(0);
	      sale.setCompanyId(ClientUtility.getCharacterDataFromElement(line));
	      //System.out.println("CompanyID: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("OrderID");
	      line = (Element) node.item(0);
	      //System.out.println("ClientUtility.getCharacterDataFromElement(line) Order Id----------!!@@@@ "+ClientUtility.getCharacterDataFromElement(line));
	      sale.setOrderId(ClientUtility.getCharacterDataFromElement(line));
	      //System.out.println("OrderID: " + ClientUtility.getCharacterDataFromElement(line));

	      node = element.getElementsByTagName("NetworkID");
	      line = (Element) node.item(0);
	      sale.setNetworkId(ClientUtility.getCharacterDataFromElement(line));
	      //System.out.println("NetworkID: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("SaleStatus");
	      line = (Element) node.item(0);
	      sale.setSaleStatus(ClientUtility.getCharacterDataFromElement(line));
	      //System.out.println("SaleStatus: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("ActionDate");
	      line = (Element) node.item(0);
	      //System.out.println("ActionDate: " + ClientUtility.getCharacterDataFromElement(line));
	      if(ClientUtility.getCharacterDataFromElement(line)!=null && !ClientUtility.getCharacterDataFromElement(line).equals(""))
	      {
	    	  sale.setActionDate(ClientUtility.getDateOnlyFromDate(ClientUtility.getCharacterDataFromElement(line)).toString());
	      }
	      
	      
	      node = element.getElementsByTagName("SaleDate");
	      line = (Element) node.item(0);
	      //System.out.println("SaleDate: " + ClientUtility.getCharacterDataFromElement(line));
	      if(ClientUtility.getCharacterDataFromElement(line)!=null && !ClientUtility.getCharacterDataFromElement(line).equals(""))
	      {
	    	  sale.setSaleDate(ClientUtility.getDateOnlyFromDate(ClientUtility.getCharacterDataFromElement(line)).toString());
	      }
	      
	      
	      node = element.getElementsByTagName("ValidatedDate");
	      line = (Element) node.item(0);
	      //System.out.println("ValidatedDate: " + ClientUtility.getCharacterDataFromElement(line));
	      if(ClientUtility.getCharacterDataFromElement(line)!=null && !ClientUtility.getCharacterDataFromElement(line).equals(""))
	      {
	    	  sale.setValidatedDate(ClientUtility.getDateOnlyFromDate(ClientUtility.getCharacterDataFromElement(line)).toString());
	      }
	      
	      
	      node = element.getElementsByTagName("SaleValue");
	      line = (Element) node.item(0);
	      //sale.setSaleValue(ClientUtility.getCharacterDataFromElement(line));
	      //System.out.println("SaleValue: " + ClientUtility.getdecimalFromString(ClientUtility.getCharacterDataFromElement(line)));
	      sale.setSaleValue(ClientUtility.getdecimalFromString(ClientUtility.getCharacterDataFromElement(line)));
	      
	      node = element.getElementsByTagName("SaleCommission");
	      line = (Element) node.item(0);
	      //sale.setSaleCommission(ClientUtility.getCharacterDataFromElement(line));
	      //System.out.println("SaleCommission: " + ClientUtility.getdecimalFromString(ClientUtility.getCharacterDataFromElement(line)));
	      sale.setSaleCommission(ClientUtility.getdecimalFromString(ClientUtility.getCharacterDataFromElement(line)));
	      
	      
	      node = element.getElementsByTagName("CreativeID");
	      line = (Element) node.item(0);
	      sale.setCreativeId(ClientUtility.getCharacterDataFromElement(line));
	    //  System.out.println("CreativeID: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("CreativeName");
	      line = (Element) node.item(0);
	      sale.setCreativeName(ClientUtility.getCharacterDataFromElement(line));
	   //   System.out.println("CreativeName: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("BannerGroupID");
	      line = (Element) node.item(0);
	      sale.setBannerGroupId(ClientUtility.getCharacterDataFromElement(line));
	 //     System.out.println("BannerGroupID: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      node = element.getElementsByTagName("BannerGroupName");
	      line = (Element) node.item(0);
	      sale.setBannerGroupName(ClientUtility.getCharacterDataFromElement(line));
	//   System.out.println("BannerGroupName: " + ClientUtility.getCharacterDataFromElement(line));
	      
	      sale.setRowEffDt(ClientUtility.getCurrentDateOnly());
	      
	      saleList.add(sale);
	    }else
	    {
	    	System.out.println("Sales It Already presnt!!!!!!!!!!!!!!!!!!!!");
	    }
	    }
		return saleList;
	}
	
	
	 
	//Create Soap Request 
	private static SOAPMessage createSOAPRequestForDgm() throws SOAPException, IOException, ParseException {
		MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();

        String serverURI = "http://www.dgperform.com/";

        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("def", serverURI);

        // SOAP Body
        SOAPBody soapBody = envelope.getBody();
        SOAPElement soapBodyElem = soapBody.addChildElement("GetSales", "def");
        SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("username");
        soapBodyElem1.addTextNode("amitava.thakur");
        SOAPElement soapBodyElem2 = soapBodyElem.addChildElement("password");
        soapBodyElem2.addTextNode("dexter1988");
        SOAPElement soapBodyElem3 = soapBodyElem.addChildElement("campaignid");
        soapBodyElem3.addTextNode("0");
        SOAPElement soapBodyElem4 = soapBodyElem.addChildElement("saleStatus");
        soapBodyElem4.addTextNode("all");
        SOAPElement soapBodyElem5 = soapBodyElem.addChildElement("dateFilterType");
        soapBodyElem5.addTextNode("approved");
        SOAPElement soapBodyElem6 = soapBodyElem.addChildElement("fromDate");
        soapBodyElem6.addTextNode("2016-01-01");
        SOAPElement soapBodyElem7 = soapBodyElem.addChildElement("toDate");
        soapBodyElem7.addTextNode(ClientUtility.getYestdayDateOnly());
        SOAPElement soapBodyElem8 = soapBodyElem.addChildElement("optionalParams");
        soapBodyElem8.addTextNode("1");

        MimeHeaders headers = soapMessage.getMimeHeaders();
        headers.addHeader("SOAPAction", serverURI  + "GetSales");

        soapMessage.saveChanges();

        // Print the request message
        //System.out.print("Request SOAP Message = ");
        soapMessage.writeTo(System.out);
        //System.out.println();
        return soapMessage;
	}
	/***********************************Section For DGM****************************************/
}
